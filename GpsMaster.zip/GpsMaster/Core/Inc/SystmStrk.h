/*
 * SystmStrk.h
 *
 *  Created on: 04-Sept-2026
 *      Author: Malcolm.X
 */

#ifndef INC_SYSTMSTRK_H_
#define INC_SYSTMSTRK_H_

#include <stdint.h>

#define SET_DATETIME   ((uint8_t)0x00)
#define READ_DATETIME  ((uint8_t)0x01)
#define DSPLY_DATETIME ((uint8_t)0x02)
#define SET_PARAM	   ((uint8_t)0x03)
#define CLCK_STTNG	   ((uint8_t)0x04)

typedef struct
{
	volatile uint8_t  SystmEvnt;
	volatile uint8_t  KeyVals;
	volatile uint8_t  ClckSttngEvnt;
	volatile uint8_t  ParamNo;
	volatile uint8_t  SlvId;
	volatile uint8_t  ParamVal;

	volatile uint8_t  ClckDlyCntr;
	volatile uint8_t  KeyDlyCntr;
	volatile uint8_t  IncKeyCntr;
	volatile uint8_t  ShftKeyCntr;
	volatile uint8_t  ClckSttngCntr;
	volatile uint8_t  GpsSnglCntr;
	volatile uint8_t  DataTrsnmtCntr;
	volatile uint16_t WtchCntr;
	volatile uint32_t MaskPrt;
} __SystmVars;

typedef struct
{
	volatile unsigned EntrKey_F         :1;
	volatile unsigned ShftKey_F         :1;
	volatile unsigned IncKey_F          :1;
	volatile unsigned ExtKey_F          :1;
	volatile unsigned KeyPrss_F		    :1;
	volatile unsigned I2c_RxCmplt_F		:1;
	volatile unsigned I2c_TxCmplt_F		:1;
	volatile unsigned ClckSttng_F		:1;
	volatile unsigned ParamSet_F		:1;
	volatile unsigned SignBit_F			:1;
	volatile unsigned GpsSnglActv_F     :1;

	volatile unsigned StrtTrsnmt_F		 :1;
	volatile unsigned ClckDlyStrt_F		 :1;
	volatile unsigned ClckDlyTmOut_F     :1;
	volatile unsigned ClckHrtBlnkStrt_F  :1;
	volatile unsigned WtchCntrStrt_F	 :1;
} __systmFalgs;

typedef struct
{
	__SystmVars SystmVars;
	__systmFalgs SystmFlags;
} __SystmStrk;

extern __SystmStrk SystmStrk;

#endif /* INC_SYSTMSTRK_H_ */
