/*
 * Clck.h
 *
 *  Created on: 03-Sept-2026
 *      Author: Malcolm.X
 */

#ifndef INC_CLCK_H_
#define INC_CLCK_H_

#include "main.h"

#define ZERO  ((uint8_t)0x3F)
#define ONE   ((uint8_t)0x06)
#define TWO   ((uint8_t)0x5B)
#define THREE ((uint8_t)0x4F)
#define FOUR  ((uint8_t)0x66)
#define FIVE  ((uint8_t)0x6D)
#define SIX   ((uint8_t)0x7D)
#define SEVEN ((uint8_t)0x07)
#define EIGHT ((uint8_t)0x7F)
#define NINE  ((uint8_t)0x6F)
#define DOT   ((uint8_t)0x80)

#define CAP_A 	  ((uint8_t)0x77)
#define CAP_C 	  ((uint8_t)0x39)
#define CAP_E     ((uint8_t)0x79)
#define CAP_F 	  ((uint8_t)0x71)
#define CAP_H 	  ((uint8_t)0x76)
#define CAP_I 	  ((uint8_t)0x06)
#define CAP_L 	  ((uint8_t)0x38)
#define CAP_N     ((uint8_t)0xB7)
#define CAP_O 	  ((uint8_t)0x3F)
#define CAP_P 	  ((uint8_t)0x73)
#define CAP_U     ((uint8_t)0x3E)
#define CAP_Y     ((uint8_t)0xE7)
#define SML_R     ((uint8_t)0x50)
#define SML_H     ((uint8_t)0x74)
#define SML_U_O   ((uint8_t)0x5C) // Display o at upper side
#define SML_L_O   ((uint8_t)0x63) // Display o at lower side
#define SML_N     ((uint8_t)0x54)
#define DOT		  ((uint8_t)0x80)
#define NGTVSIGN  ((uint8_t)0x40)
#define DSPLYNOP  ((uint8_t)0x00)

#define HRSTEN_DGT ((uint8_t)0x01)
#define HRSUNT_DGT ((uint8_t)0x02)
#define MINTEN_DGT ((uint8_t)0x03)
#define MINUNT_DGT ((uint8_t)0x04)
#define SECTEN_DGT ((uint8_t)0x05)
#define SECUNT_DGT ((uint8_t)0x06)
#define DATETEN_DGT ((uint8_t)0x07)
#define DATEUNT_DGT ((uint8_t)0x08)
#define MNTHTEN_DGT ((uint8_t)0x09)
#define MNTHUNT_DGT ((uint8_t)0x0A)
#define YEARTEN_DGT ((uint8_t)0x0B)
#define YEARUNT_DGT ((uint8_t)0x0C)

#define PARAM_00   ((uint8_t)0x00)   // Clock mode.
#define PARAM_01   ((uint8_t)0x01)   // Set Am / Pm, 1 = Pm , 0 = Am.
#define PARAM_02   ((uint8_t)0x02)	 // Set Hrs.
#define PARAM_03   ((uint8_t)0x03)	 // Set Min.
#define PARAM_04   ((uint8_t)0x04)	 // Set Sec.
#define PARAM_05   ((uint8_t)0x05)	 // Set Date.
#define PARAM_06   ((uint8_t)0x06)	 // Set Month.
#define PARAM_07   ((uint8_t)0x07)	 // Set Year.
#define PARAM_08   ((uint8_t)0x08)	 // Set Week.
#define PARAM_09   ((uint8_t)0x09)   // Set Slave Id.
#define PARAM_10   ((uint8_t)0x0A)   // UTC offset.
#define CLR_DGIT   ((uint8_t)0x0B)
#define PARAM_SET  ((uint8_t)0x0C)
#define SHW_SUSS   ((uint8_t)0x0D)

#define DATE_MAX    ((uint8_t)0x1F)  // Date max value 31.
#define DATE_MIN    ((uint8_t)0x01)  // Date min value 01.
#define MINT_MAX    ((uint8_t)0x3B)  // Minute max value 59.
#define MINT_MIN    ((uint8_t)0x00)  // Minute min value 00.
#define SECN_MAX    ((uint8_t)0x3B)  // Seconds max value 59.
#define SECN_MIN    ((uint8_t)0x00)  // Seconds min value 00.

#define _24HRS2MIN  ((uint16_t)0x5A0)  // 24 hrs in minute 1440 minutes.
#define EPROM_ADDRS_W ((uint8_t)0b10100000) // Epprom address for write (0xA0).
#define EPROM_ADDRS_R ((uint8_t)0b10100001) // Epprom address for read  (0xA1).

typedef struct
{
	volatile uint8_t  DSplySwtchEvnt;
	volatile uint8_t  DsplyDlyCntr;
	volatile uint8_t  DsplySwCntr;
	volatile  int8_t  HrsUtcOffst;
	volatile  int8_t  MinUtcOffst;

	volatile uint16_t DsplyBlnkCntr;
	volatile uint8_t  DSplyBffr[12];
} __DsplyVars;

typedef struct
{
	volatile unsigned DsplyWrtCmplt_F   :1;
	volatile unsigned DsplyInit_F       :1;
	volatile unsigned ClckHrt_F		    :1;
	volatile unsigned GpsSgnlLed_F		:1;

	volatile unsigned DsplySwTmOt_F     :1;
	volatile unsigned DsplySwStrt_F     :1;
	volatile unsigned DsplBlnkStrt_F	:1;
	volatile unsigned DSplyBlnkTmOut_F  :1;
	volatile unsigned DsplyDlyStrt_F	:1;
	volatile unsigned DsplyDlyTmOut_F   :1;
} __DsplyFlags;

typedef struct
{
	__DsplyVars  DsplyVars;
	__DsplyFlags DsplyFlags;
} __DsplyStrk;

typedef struct
{
	volatile unsigned EgthDsply  	  :1;  // 1
	volatile unsigned SvntDsply  	  :1;  // 2
	volatile unsigned YearUntSgmnt_F  :1;  // 3
	volatile unsigned YearTenSgmnt_F  :1;  // 4
	volatile unsigned MnthUntSgmnt_F  :1;  // 5
	volatile unsigned MnthTenSgmnt_F  :1;  // 6
	volatile unsigned DateUntSgmnt_F  :1;  // 7
	volatile unsigned DateTenSgmnt_F  :1;  // 8

	volatile unsigned GpsAtcv_F       :1;  // 9
	volatile unsigned Clck_Hrst_F     :1;  // 10
	volatile unsigned SecUntSgmnt_F   :1;  // 11
	volatile unsigned SecTenSgmnt_F   :1;  // 12
	volatile unsigned MinUntSgmnt_F	  :1;  // 13
	volatile unsigned MinTenSgmnt_F	  :1;  // 14
	volatile unsigned HrsUntSgmnt_F   :1;  // 15
	volatile unsigned HrsTenSgmnt_F   :1;  // 16

} __SgmntFlags;

typedef union
{
	__SgmntFlags 	  SgmntFlags;
	volatile uint16_t SgmntVar;
} __SgmntUn;

extern __SgmntUn   SgmntUn;
extern __DsplyStrk DsplyStrk;
extern uint8_t DsplyNumArr[];

void G_SetData_Mth		   (void);
void SwtchDsply	  		   (void);
void DsplyClck_Mth		   (void);
void ClrBffr	     	   (void);
void Clck_sttng			   (void);
void AddUtcOffst_ToLclTim  (void);

enum
{
	False,
	True
};

enum
{
	HrsTenDgt,   // 0
	HrsUntDgt,   // 1
	MinTenDgt,   // 2
	MinUntDgt,   // 3
	SecTenDgt,   // 4
	SecUntDgt,   // 5
	DateTenDgt,  // 6
	DateUntDgt,  // 7
	MnthTenDgt,  // 8
	MnthUntDgt,  // 9
	YearTenDgt,  // 10
	YearUntDgt   // 11
};

#endif /* INC_CLCK_H_ */
