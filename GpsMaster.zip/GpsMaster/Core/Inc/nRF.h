/*
 * Uart.h
 *
 *  Created on: 27-Aug-2026
 *      Author: Malcolm.X
 */

#ifndef INC_NRF_H_
#define INC_NRF_H_

#include "main.h"

typedef struct
{
    volatile uint8_t nRFInitEvnt;
    volatile uint8_t nRFTrnsmtEvnt;
    volatile uint8_t nRFdlyCntr;
    volatile uint8_t nRFFailerCntr;
             uint8_t statusCmd;
             uint8_t StatusReg;
             uint8_t nRFTxBffr[8];
             uint8_t nRFCmdBffr[6];
} __nRFVars;

typedef struct
{
    volatile unsigned nRFTxCmplt_F     :1;
	volatile unsigned nRFRxCmplt_F     :1;
	volatile unsigned nRFInit_F        :1;
	volatile unsigned nRFDlyStrt_F     :1;
	volatile unsigned nRFDlyTmOut_F    :1;
	volatile unsigned nRFRxTxCmplt_F   :1;
	volatile unsigned nRFBlnk_F		   :1;
	volatile unsigned nRFstrtTx	       :1;
} __nRFFlags;

typedef struct
{
	__nRFVars  nRFVars;
	__nRFFlags nRFFlags;
} _nRF24Strk;

extern _nRF24Strk nRF24Strk;

/*----------------------------nrf24l01 Register address----------------------------*/

#define W_TX_PAYLOAD_NOACK ((uint8_t)0xB0)
#define R_RX_PAYLOAD       ((uint8_t)0x61)
#define WRT_REG_CMD        ((uint8_t)0x20)
#define READ_REG_CMD       ((uint8_t)0x00)
#define TRNSMT_CMD		   ((uint8_t)0xA0)

#define CONFIG_REG_ADDRS        ((uint8_t)0x00)
#define ENAA_REG_ADDRS          ((uint8_t)0x01)  // Auto-Acknowledgment
#define EN_RXADDR_ADDRS         ((uint8_t)0x02)  // Enabled RX Addresses
#define SETUP_AW_REG_ADDRS      ((uint8_t)0x03)  // Address Widths
#define SETUP_RETR_REG_ADDRS    ((uint8_t)0x04)  // Automatic Retransmission
#define RF_CH_REG_ADDRS         ((uint8_t)0x05)  // RF Channel
#define RF_SETUP_REG_ADDRS      ((uint8_t)0x06)  // RF Setup (Data rate, Power)
#define STATUS_REG_ADDRS        ((uint8_t)0x07)
#define RX_ADDR_P0_REG_ADDRS    ((uint8_t)0x0A)  // Receive Address Pipe 0
#define TX_ADDR_REG_ADDRS       ((uint8_t)0x10)  // Transmit Address
#define RX_PW_P0_REG_ADDRS      ((uint8_t)0x11)  // Payload Width Pipe 0
#define FEATURE_REG_ADDRS       ((uint8_t)0x1D)  // Feature Register
#define FLUSH_TX             	((uint8_t)0x0B)
#define CLR_IRQ                 ((uint8_t)0x0C)
#define DUMMPY_DATA             ((uint8_t)0x0D)

/*----------------------------nrf24l01 Register address end------------------------*/

#define TRNSMT_DATA	  ((uint8_t)0x00)
#define PULSE_CE	  ((uint8_t)0x01)
#define READ_STATUS	  ((uint8_t)0x02)
#define CLR_STATUS	  ((uint8_t)0x03)
#define FLSH_TXFIFO   ((uint8_t)0x04)
#define TRNSMT_CMPLT  ((uint8_t)0x05)

#define CSN_LOW()   HAL_GPIO_WritePin(GPIOA, CSN_PA8_Pin, GPIO_PIN_RESET)
#define CSN_HIGH()  HAL_GPIO_WritePin(GPIOA, CSN_PA8_Pin, GPIO_PIN_SET)
#define CE_LOW()    HAL_GPIO_WritePin(GPIOB, CE_RXTX_PB12_Pin, GPIO_PIN_RESET)
#define CE_HIGH()   HAL_GPIO_WritePin(GPIOB, CE_RXTX_PB12_Pin, GPIO_PIN_SET)

void Init_nRF24      (void);
void nRF24_SetTxMode (void);
void nRF24_SetRxMode (void);
void nRFTx_Data		 (void);
void SetDly			 (uint16_t DlyCnt);
void nRF_SetCmd 	 (uint8_t NumofByt2Snd);

#endif /* INC_NRF_H_ */
