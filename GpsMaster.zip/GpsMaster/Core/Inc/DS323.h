/*
 * DS323.h
 *
 *  Created on: 11-Jun-2026
 *      Author: Malcolm.X
 */

#ifndef INC_DS323_H_
#define INC_DS323_H_

#include <stdint.h>
#include "main.h"

/*-----------------------------------------------*/
typedef struct __DateTmVars
{
	volatile uint8_t  SecCntr;
	volatile uint8_t  MinCntr;
	volatile uint8_t  HrsCntr;
	volatile uint8_t  DayVal;
	volatile uint8_t  DateVal;
	volatile uint8_t  MnthVal;
	volatile uint16_t YrsVal;
	volatile uint16_t MillSecCntr;
			 uint8_t  RtcBuffr[8];
} _DateTmVars;

typedef struct __DateTmFlags
{
	volatile unsigned AmPM_F		       :1;
	volatile unsigned Hrs24_12_F           :1;
	volatile unsigned WrtDateTm_F		   :1;
	volatile unsigned WrtDateTmCmplt_F     :1;
} _DateTmFlags;

typedef struct __DateTmStrk
{
	_DateTmVars  DateTmVars;
	_DateTmFlags DateTmFlags;
} _DateTmStrk;

extern _DateTmStrk DateTmStrk;
/*-----------------------------------------------*/

/*------------------------------------------------------------------------------*/
void GetTime      (void);
void GetDate      (void);
void GetDateTime  (void);
void ClrBuffr     (void);
void SetDateTime  (void);
void GetDateInBcd (void);

void I2c_Wrt_DateTm (uint8_t *PtrData, uint8_t MemAddrs, uint8_t NumOfByts);
void I2C_Red_DateTm (uint8_t *PtrData, uint8_t MemAddrs, uint8_t NumOfByts);

uint8_t Dcml2Bcd (volatile uint8_t TmpData);
uint8_t Bcd2Dcml (volatile uint8_t TmpData);
/*-----------------------------------------------------------------------------*/

/*------------------------------------------------------------------*/
#define RTC_ADDR_R    0b11010001 // 0xD1
#define RTC_ADDR_W    0b11010000 // 0xD0
#define SEC_REG_ADDR  0x00
#define MIN_REG_ADDR  0x01
#define HRS_REG_ADDR  0x02
#define DAY_REG_ADDR  0x03
#define DATE_REG_ADDR 0x04
#define MNT_REG_ADDR  0x05
#define YER_REG_ADDR  0x06

#define __AM__        0x5F
#define __PM__        0x20
#define __12HRS__     0x40
#define __24HRS__     0x3F
#define __TNSBIT__    0x1F
#define __TWNTYBIT__  0x3F
#define __12HRSMD__   0x0C
#define __24HRSMD__   0x18
#define RTC_BFFR_LEN  0x08
/*-----------------------------------------------------------------------*/

/*---------------------------*/
enum
{
	Unused,
	ClckMod,
	DateMod,
	DateTmMod
};
/*---------------------------*/

/*---------------------------*/
enum
{
	ScltAm,
	ScltPm
};
/*---------------------------*/

/*---------------------------*/
enum
{
	Sclt24Hrs,
	Sclt12Hrs
};
/*---------------------------*/

#endif /* INC_DS323_H_ */
