/*
 * Uart.c
 *
 *  Created on: 05-Sept-2026
 *      Author: Malcolm.X
 */
#include "Uart.h"

// $GPRMC,095559.084,V,,,,,0.00,0.00,150926,,,N,V*37
__UartStrk UrtStrk;

/*void ChckRqust (void)
{
	if (UrtStrk.UrtVars.UrtBffr[0] == MDBS_SLV_ADDR)
	{
        UrtStrk.UrtVars.RegStrtAddrs = UrtStrk.UrtVars.UrtBffr[3];
        if(UrtStrk.UrtVars.RegStrtAddrs >=0 && UrtStrk.UrtVars.RegStrtAddrs <= 8)
        {
            UrtStrk.UrtVars.RegCnt = UrtStrk.UrtVars.UrtBffr[5];
            if(UrtStrk.UrtVars.RegCnt <= 10)
            {
            	DateTmStrk.DateTmFlags.WrtDateTm_F = False;
                HAL_GPIO_WritePin(GPIOA, URT_DR_PA11_Pin, GPIO_PIN_SET);
				CrtRspons();
				if (DateTmStrk.DateTmFlags.WrtDateTm_F)
				{
					DateTmStrk.DateTmFlags.WrtDateTm_F = False;
					SetDateTime();
				}
            }
        }
	}
}*/

void CrtRspons(void)
{
    //uint8_t  Dffrnc = 0, FrstTrm = 0, EndAddr = 0, StrtAddrs = 0, NumOfByts = 0, BffrCntr = 0;
	uint8_t BffrCntr = 0;
	uint16_t CRCVal = 0;
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = MDBS_SLV_ADDR; // Slave Id.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x10; // Function code Reading holding register.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00; // Address Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00; // Address Lw Byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00; // Quantity Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x08; // Quantity Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x10; // Data byte count.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00; // Hrs Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.HrsCntr; // Hrs Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;						     // Min Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.MinCntr; // Min Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;							 // Sec Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.SecCntr; // Sec Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;							 // Date Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.DateVal; // Date Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;							 // Month Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.MnthVal; // Month Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x14;							 // Year Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.YrsVal;  // Year Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;						     // Day Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.DayVal;  // Day Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;							 // Clock mode.
	if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt12Hrs)
	{
		if (DateTmStrk.DateTmFlags.AmPM_F == ScltPm)
		{
			UrtStrk.UrtVars.UrtBffr[BffrCntr++] =112;
		}
		else
		{
			UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 12;
		}
	}
	else
	{
		UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 24;
	}

	CRCVal = Calculate_CRC(UrtStrk.UrtVars.UrtBffr, BffrCntr);
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = (uint8_t)(CRCVal  & 0xFF);
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = (uint8_t)((CRCVal >> 0x08) & 0xFF);
	HAL_UART_Transmit_DMA(&huart1, UrtStrk.UrtVars.UrtBffr, BffrCntr);
}

uint16_t Calculate_CRC(const uint8_t *pBuffer, uint16_t Length)
{
	uint16_t crc = 0xFFFF; // Modbus initial value
	uint16_t BffrCntr = 0;
    for (; BffrCntr < Length; BffrCntr++)
    {
        crc ^= pBuffer[BffrCntr]; // XOR byte into least sig. byte of crc
        for (uint8_t bit = 0; bit < 8; bit++)
        {
            if (crc & 0x0001)
            { // If the LSB is set
                crc >>= 1;
                crc ^= 0xA001;  // Modbus bit-reversed polynomial
            }
            else
            {
                crc >>= 1;
            }
        }
    }
    return crc;
}

void ParseGpsDateTime(void)
{
	uint8_t BffrCntr = 0, CmaCntr = 0, RMCFnd_F = 0,RMCCntr = 0;
	for(; BffrCntr < URT_BFFR_LEN; BffrCntr++)
	{
		if ((UrtStrk.UrtVars.GpsBffr[RMCCntr] == 'R') && (UrtStrk.UrtVars.GpsBffr[RMCCntr+1] == 'M') && (UrtStrk.UrtVars.GpsBffr[RMCCntr+2] == 'C'))
		{
			UrtStrk.UrtFlags.GpsDlyTmOut_F = False;
			UrtStrk.UrtFlags.GpsDlyStrt_F  = True;
			if (UrtStrk.UrtVars.GpsBffr[RMCCntr+15] == 'A')
			{
				SystmStrk.SystmFlags.GpsSnglActv_F = True;
				RMCFnd_F						   = True;
				UrtStrk.UrtVars.UTcHrs  	   = (UrtStrk.UrtVars.GpsBffr[RMCCntr+4] & 0x0F) * 10;
				UrtStrk.UrtVars.UTcHrs 		  += (UrtStrk.UrtVars.GpsBffr[RMCCntr+5] & 0x0F);
				UrtStrk.UrtVars.UtcMin  	   = (UrtStrk.UrtVars.GpsBffr[RMCCntr+6] & 0x0F) * 10;
				UrtStrk.UrtVars.UtcMin        += (UrtStrk.UrtVars.GpsBffr[RMCCntr+7] & 0x0F);
				DateTmStrk.DateTmVars.SecCntr  = (UrtStrk.UrtVars.GpsBffr[RMCCntr+8] & 0x0F) * 10;
				DateTmStrk.DateTmVars.SecCntr += (UrtStrk.UrtVars.GpsBffr[RMCCntr+9] & 0x0F);
			}
			else
			{
				if ((URT_BFFR_LEN - RMCCntr) > 15)
				{
					SystmStrk.SystmFlags.GpsSnglActv_F = False;
				}
				break;
			}
		}
		else
		{
			RMCCntr++;
		}
		if (RMCFnd_F)
		{
			if (UrtStrk.UrtVars.GpsBffr[BffrCntr] == ',')
			{
				CmaCntr++;
			}
			if (CmaCntr >= 10)
			{
				CmaCntr = 0;
				if (SystmStrk.SystmFlags.GpsSnglActv_F)
				{
					DateTmStrk.DateTmVars.YrsVal   = (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F);
					DateTmStrk.DateTmVars.YrsVal  += (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F)*10;
					DateTmStrk.DateTmVars.MnthVal  = (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F);
					DateTmStrk.DateTmVars.MnthVal += (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F)*10;
					DateTmStrk.DateTmVars.DateVal  = (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F);
					DateTmStrk.DateTmVars.DateVal += (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F)*10;
					AddUtcOffst_ToLclTim();
					SetDateTime();
					UrtStrk.UrtVars.GpsDlyCnt = 1999;
				}
				break;
			}
		}
	}
}
