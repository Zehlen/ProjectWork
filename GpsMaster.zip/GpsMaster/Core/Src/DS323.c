/*
 * DS323.c
 *
 *  Created on: 25-May-2026
 *      Author: Malcoml.X
 */


#include "DS323.h"

_DateTmStrk DateTmStrk;

/**
  * @brief Send Data and Time.
  * @note  Set Date and Time from DateTmStrk to RTC buffer for sending.
  * @param  None.
  * @retval None
*/
void SetDateTime(void)
{
	uint8_t hrsBcd = 0;
	DateTmStrk.DateTmVars.RtcBuffr[0] = Dcml2Bcd(DateTmStrk.DateTmVars.SecCntr);
	DateTmStrk.DateTmVars.RtcBuffr[1] = Dcml2Bcd(DateTmStrk.DateTmVars.MinCntr);

	if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt12Hrs)
	{
		hrsBcd = Dcml2Bcd(DateTmStrk.DateTmVars.HrsCntr) & __TNSBIT__;
		hrsBcd |= __12HRS__; // Set Bit 6 explicitly for 12-hour mode

		if (DateTmStrk.DateTmFlags.AmPM_F == ScltPm)
		{
			hrsBcd |= __PM__; // Set Bit 5 explicitly for PM
		}
	}
	else
	{
		// 24-hour mode requires shifting the full BCD byte including bits 4 and 5
		hrsBcd = Dcml2Bcd(DateTmStrk.DateTmVars.HrsCntr) & __TWNTYBIT__;
	}
	DateTmStrk.DateTmVars.RtcBuffr[2] = hrsBcd;
	DateTmStrk.DateTmVars.RtcBuffr[3] = DateTmStrk.DateTmVars.DayVal;
	DateTmStrk.DateTmVars.RtcBuffr[4] = Dcml2Bcd(DateTmStrk.DateTmVars.DateVal) & __TWNTYBIT__;
	DateTmStrk.DateTmVars.RtcBuffr[5] = Dcml2Bcd(DateTmStrk.DateTmVars.MnthVal) & __TNSBIT__;
	DateTmStrk.DateTmVars.RtcBuffr[6] = Dcml2Bcd(DateTmStrk.DateTmVars.YrsVal) & __TWNTYBIT__;

	I2c_Wrt_DateTm(DateTmStrk.DateTmVars.RtcBuffr, SEC_REG_ADDR, 7);
}

/**
  * @brief Send Data and Time.
  * @note  Set Date and Time from RTC buffer to DateTmStrk.
  * @param  None.
  * @retval None
*/
void GetDateTime(void)
{
	DateTmStrk.DateTmVars.SecCntr = Bcd2Dcml(DateTmStrk.DateTmVars.RtcBuffr[0]);
	DateTmStrk.DateTmVars.MinCntr = Bcd2Dcml(DateTmStrk.DateTmVars.RtcBuffr[1]);
	if (DateTmStrk.DateTmVars.RtcBuffr[2] & __12HRS__)
	{
		DateTmStrk.DateTmFlags.Hrs24_12_F = Sclt12Hrs;
		DateTmStrk.DateTmVars.HrsCntr     = Bcd2Dcml((DateTmStrk.DateTmVars.RtcBuffr[2] & __TNSBIT__));
		if (DateTmStrk.DateTmVars.RtcBuffr[2] & __PM__)
		{
			DateTmStrk.DateTmFlags.AmPM_F = ScltPm;
		}
		else
		{
			DateTmStrk.DateTmFlags.AmPM_F = ScltAm;
		}
	}
	else
	{
		DateTmStrk.DateTmFlags.Hrs24_12_F = Sclt24Hrs;
		DateTmStrk.DateTmVars.HrsCntr     = Bcd2Dcml((DateTmStrk.DateTmVars.RtcBuffr[2] & __TWNTYBIT__));
	}
	DateTmStrk.DateTmVars.DayVal  = Bcd2Dcml(DateTmStrk.DateTmVars.RtcBuffr[3]);
	DateTmStrk.DateTmVars.DateVal = Bcd2Dcml(DateTmStrk.DateTmVars.RtcBuffr[4]);
	DateTmStrk.DateTmVars.MnthVal = Bcd2Dcml(DateTmStrk.DateTmVars.RtcBuffr[5] & __TNSBIT__);
	DateTmStrk.DateTmVars.YrsVal  = Bcd2Dcml(DateTmStrk.DateTmVars.RtcBuffr[6] & __TWNTYBIT__);
}

void GetDateInBcd(void)
{
	DateTmStrk.DateTmVars.SecCntr = DateTmStrk.DateTmVars.RtcBuffr[0];
	DateTmStrk.DateTmVars.MinCntr = DateTmStrk.DateTmVars.RtcBuffr[1];
	DateTmStrk.DateTmVars.HrsCntr = DateTmStrk.DateTmVars.RtcBuffr[2];
	DateTmStrk.DateTmVars.DayVal  = DateTmStrk.DateTmVars.RtcBuffr[3];
	DateTmStrk.DateTmVars.DateVal = DateTmStrk.DateTmVars.RtcBuffr[4];
	DateTmStrk.DateTmVars.MnthVal = DateTmStrk.DateTmVars.RtcBuffr[5];
	DateTmStrk.DateTmVars.YrsVal  = DateTmStrk.DateTmVars.RtcBuffr[6];
}

void ClrBuffr(void)
{
	uint8_t BffrCntr = 0;
	for(; BffrCntr < RTC_BFFR_LEN; BffrCntr++)
	{
		DateTmStrk.DateTmVars.RtcBuffr[BffrCntr] = 0;
	}
}

/**
  * @brief  Write data and time in MAX7219.
  * @note   Write data in continues way from starting memory address using HALHAL_I2C_Mem_Write_IT.
  * @note   After write generate interrupt.
  * @param  PtrData   : pointer to data buffer.
  * @param  MemAddrs  : Starting Memory address to write.
  * @param  NumOfByts : Number of bytes to write.
  * @retval None
*/
void I2c_Wrt_DateTm(uint8_t *PtrData, uint8_t MemAddrs, uint8_t NumOfByts)
{
	HAL_I2C_Mem_Write_IT(&hi2c1, RTC_ADDR_W, MemAddrs, I2C_MEMADD_SIZE_8BIT, PtrData, NumOfByts);
//	HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, DVICADDR_W, PtrData, NumOfByts, I2C_FIRST_FRAME);
}

/**
  * @brief  Read data and time in MAX7219.
  * @note   Read data in continues way from starting memory address using HALHAL_I2C_Mem_Read_IT.
  * @note   After reading generate interrupt.
  * @param  PtrData   : pointer to data buffer.
  * @param  MemAddrs  : Starting Memory address to read.
  * @param  NumOfByts : Number of bytes to read.
  * @retval None
*/
void I2C_Red_DateTm(uint8_t *PtrData, uint8_t MemAddrs, uint8_t NumOfByts)
{
	HAL_I2C_Mem_Read_IT(&hi2c1, RTC_ADDR_R, MemAddrs, I2C_MEMADD_SIZE_8BIT, PtrData, NumOfByts);
//	HAL_I2C_Master_Seq_Receive_IT(&hi2c1, DVICADDR_R, PtrData, NumOfByts, I2C_FIRST_FRAME);
}

uint8_t Dcml2Bcd(uint8_t TmpData)
{
	uint8_t TmpVal = 0;
	TmpVal  = (TmpData / 10) << 4;
	TmpVal +=  TmpData % 10;
	return TmpVal;
}

uint8_t Bcd2Dcml(uint8_t TmpData)
{
	uint8_t TmpVal = 0;
	TmpVal  = (TmpData / 0x10)*10;
	TmpVal += TmpData % 0x10;
	return TmpVal;
}
