/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

SPI_HandleTypeDef hspi2;

TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart3;
DMA_HandleTypeDef hdma_usart1_rx;
DMA_HandleTypeDef hdma_usart1_tx;
DMA_HandleTypeDef hdma_usart3_rx;
DMA_HandleTypeDef hdma_usart3_tx;
__SystmStrk 	  SystmStrk;
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_SPI2_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI2_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();
  MX_I2C1_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  HAL_GPIO_WritePin(GPIOC, SHCP_PC15_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOC, STCP_PC14_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOA, URT_DR_PA11_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOA, CSN_PA8_Pin, GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, CE_RXTX_PB12_Pin, GPIO_PIN_RESET);
  DsplyStrk.DsplyFlags.DsplyWrtCmplt_F   = True;
  DsplyStrk.DsplyFlags.DsplySwTmOt_F     = True;
  UrtStrk.UrtFlags.GpsDlyTmOut_F 	     = True;
  UrtStrk.UrtFlags.GpsRxCmplt_F          = True;
  SystmStrk.SystmFlags.ClckHrtBlnkStrt_F = True;
  nRF24Strk.nRFFlags.nRFTxCmplt_F 		 = True;
  UrtStrk.UrtVars.GpsDlyCnt 			 = 199;
  while (1)
  {
	  if (!nRF24Strk.nRFFlags.nRFInit_F)
	  {
		  Init_nRF24();
	  }
	  else
	  {
		  if (DsplyStrk.DsplyFlags.DsplyWrtCmplt_F)
		  {
			  DsplyStrk.DsplyFlags.DsplyWrtCmplt_F = False;
			  switch (SystmStrk.SystmVars.SystmEvnt)
			  {
				  case SET_DATETIME:
					  HAL_I2C_Mem_Read_IT(&hi2c1, EPROM_ADDRS_R, 0x00, I2C_MEMADD_SIZE_16BIT, UrtStrk.UrtVars.UrtBffr, 3);
					  SystmStrk.SystmVars.SystmEvnt = SET_PARAM;
				  break;
				  case SET_PARAM:
					  if (SystmStrk.SystmFlags.I2c_RxCmplt_F)
					  {
						  SystmStrk.SystmFlags.I2c_RxCmplt_F  = False;
						  DsplyStrk.DsplyVars.HrsUtcOffst     = UrtStrk.UrtVars.UrtBffr[0];
						  DsplyStrk.DsplyVars.MinUtcOffst     = UrtStrk.UrtVars.UrtBffr[1];
						  SystmStrk.SystmVars.SlvId           = UrtStrk.UrtVars.UrtBffr[2];
						  SystmStrk.SystmFlags.ClckDlyTmOut_F = True;
						  SystmStrk.SystmFlags.WtchCntrStrt_F = True;
						  SystmStrk.SystmFlags.StrtTrsnmt_F   = True;
						  SystmStrk.SystmVars.SystmEvnt   	  = READ_DATETIME;
					  }
				  break;
				  case READ_DATETIME:
					  if (SystmStrk.SystmFlags.ClckDlyTmOut_F)
					  {
						  SystmStrk.SystmFlags.ClckDlyTmOut_F = False;
						  I2C_Red_DateTm(DateTmStrk.DateTmVars.RtcBuffr, SEC_REG_ADDR, 7);
					  }
					  if (SystmStrk.SystmFlags.I2c_RxCmplt_F)
					  {
						  SystmStrk.SystmFlags.I2c_RxCmplt_F = False;
						  GetDateTime();
						  DsplyClck_Mth();
						  SystmStrk.SystmFlags.ClckDlyStrt_F    = True;
						  SystmStrk.SystmVars.SystmEvnt		    = CLCK_STTNG;
						  DsplyStrk.DsplyFlags.DSplyBlnkTmOut_F = True;
						  SystmStrk.SystmVars.ClckSttngEvnt     = CLR_DGIT;
					  }
				  break;
				  case CLCK_STTNG:
					  if (SystmStrk.SystmFlags.ClckSttng_F)
					  {
						  DsplyStrk.DsplyFlags.DsplBlnkStrt_F    = True;
						  SystmStrk.SystmFlags.ClckHrtBlnkStrt_F = False;
						  DsplyStrk.DsplyFlags.ClckHrt_F         = False;
						  Clck_sttng();
					  }
					  else
					  {
						  DsplyStrk.DsplyFlags.DsplBlnkStrt_F    = False;
						  SystmStrk.SystmFlags.ClckHrtBlnkStrt_F = True;
						  SystmStrk.SystmVars.SystmEvnt 	     = READ_DATETIME;
					  }
				  break;
			  }
		  }
		  else
		  {
			  /*if (UrtStrk.UrtFlags.MdbsRxCmplt_F)
			  {
				UrtStrk.UrtFlags.MdbsRxCmplt_F  = False;
				UrtStrk.UrtFlags.MdbsDlyStrt_F  = False;
				UrtStrk.UrtFlags.MdbsDlyTmOut_F = False;
				ChckRqust();   // check modbus request.
				UrtStrk.UrtFlags.MdbsDlyStrt_F = True;
			  }
			  if (UrtStrk.UrtFlags.MdbsDlyTmOut_F)
			  {
				UrtStrk.UrtFlags.MdbsTxCmplt_F  = False;
				UrtStrk.UrtFlags.MdbsDlyTmOut_F = False;
				HAL_GPIO_WritePin(GPIOA, URT_DR_PA11_Pin, GPIO_PIN_RESET);
				HAL_UART_Receive_DMA(&huart1, UrtStrk.UrtVars.UrtBffr, 25);  // Turn UART to receive mode.
			  }*/

			  if (UrtStrk.UrtFlags.GpsDlyTmOut_F)
			  {
				  if (UrtStrk.UrtFlags.GpsRxCmplt_F)
				  {
					  UrtStrk.UrtFlags.GpsRxCmplt_F = False;
					  ParseGpsDateTime();
					  HAL_UART_Receive_DMA(&huart3, UrtStrk.UrtVars.GpsBffr, URT_BFFR_LEN);
				  }
			  }
			  if (DateTmStrk.DateTmFlags.WrtDateTm_F)
			  {
				  DateTmStrk.DateTmFlags.WrtDateTm_F = False;
				  SystmStrk.SystmFlags.StrtTrsnmt_F  = False;
				  nRF24Strk.nRFFlags.nRFstrtTx       = True;
				  nRF24Strk.nRFFlags.nRFTxCmplt_F 	 = True;
				  HAL_GPIO_WritePin(GPIOA, URT_DR_PA11_Pin, GPIO_PIN_SET);
			  }
			  if (nRF24Strk.nRFFlags.nRFstrtTx)
			  {
				  nRFTx_Data();
			  }
		  }
		  if (DsplyStrk.DsplyFlags.DsplySwTmOt_F)
		  {
			  DsplyStrk.DsplyFlags.DsplySwTmOt_F = False;
			  SwtchDsply();
		  }
	  }
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 63;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 999;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_TIM_Base_Start_IT(&htim3);
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
//static void MX_TIM4_Init(void)
//{
//
//  /* USER CODE BEGIN TIM4_Init 0 */
////
//  /* USER CODE END TIM4_Init 0 */
//
//  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
//  TIM_MasterConfigTypeDef sMasterConfig = {0};
//
//  /* USER CODE BEGIN TIM4_Init 1 */
////
//  /* USER CODE END TIM4_Init 1 */
//  htim4.Instance = TIM4;
//  htim4.Init.Prescaler = 63;
//  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
//  htim4.Init.Period = 4999;
//  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
//  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
//  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
//  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
//  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
//  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
//  {
//    Error_Handler();
//  }
//  /* USER CODE BEGIN TIM4_Init 2 */
////
//  /* USER CODE END TIM4_Init 2 */
//
//}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 9600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);
  /* DMA1_Channel3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel3_IRQn);
  /* DMA1_Channel4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel4_IRQn);
  /* DMA1_Channel5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel5_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, DS_PC13_Pin|SHCP_PC15_Pin|STCP_PC14_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, SEG_A_PA0_Pin|SEG_B_PA1_Pin|SEG_C_PA2_Pin|SEG_D_PA3_Pin
                          |SEG_E_PA4_Pin|SEG_F_PA5_Pin|SEG_G_PA6_Pin|SEG_H_PA7_Pin
                          |CSN_PA8_Pin|URT_DR_PA11_Pin|CLCK_PM_PA12_Pin|CLCK_AM_PA15_Pin, GPIO_PIN_RESET);


  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, CE_RXTX_PB12_Pin|CLCK_HRT_PB9_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : DS_PC13_Pin SHCP_PC14_Pin STCP_PC15_Pin */
  GPIO_InitStruct.Pin = DS_PC13_Pin|SHCP_PC15_Pin|STCP_PC14_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : SEG_A_PA0_Pin SEG_B_PA1_Pin SEG_C_PA2_Pin SEG_D_PA3_Pin
                           SEG_E_PA4_Pin SEG_F_PA5_Pin SEG_G_PA6_Pin SEG_H_PA7_Pin
                           CSN_PA8_Pin URT_DR_PA11_Pin CLCK_PM_PA12_Pin CLCK_AM_PA15_Pin */
  GPIO_InitStruct.Pin = SEG_A_PA0_Pin|SEG_B_PA1_Pin|SEG_C_PA2_Pin|SEG_D_PA3_Pin
                          |SEG_E_PA4_Pin|SEG_F_PA5_Pin|SEG_G_PA6_Pin|SEG_H_PA7_Pin
                          |CSN_PA8_Pin|URT_DR_PA11_Pin|CLCK_PM_PA12_Pin|CLCK_AM_PA15_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : ENTR_PB0_Pin SHFT_PB1_Pin EXT_PB3_Pin INC_PB4_Pin */
  GPIO_InitStruct.Pin = ENTR_PB0_Pin|SHFT_PB1_Pin|EXT_PB3_Pin|INC_PB4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : CE_RXTX_PB12_Pin CLCK_HRT_PB9_Pin */
  GPIO_InitStruct.Pin = CE_RXTX_PB12_Pin|CLCK_HRT_PB9_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);

  HAL_NVIC_SetPriority(EXTI1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);

  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
