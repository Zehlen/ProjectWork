/*
 * Clck.c
 *
 *  Created on: 03-Sept-2026
 *      Author: Malcolm.X
 */

#include "Clck.h"

__SgmntUn SgmntUn;
__DsplyStrk DsplyStrk;

uint8_t DsplyNumArr[] = {ZERO,ONE,TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE};
uint8_t OffstCntr     = 0;
uint8_t OffStCnt 	  = 0;
uint8_t UntDgt		  = 0;
uint8_t TenDgt		  = 0;
uint8_t ScndTenDgt    = 0;
uint8_t ScndUntDgt    = 0;

/**
 * @brief  : Clock setting set hrs, min, sec, date,month, year, clcok mode, Am/Pm.
 * Turn setting on when shift and increase key hold for 10 sec.
 * @param  : None.
 * @retval : None.
**/
void Clck_sttng(void)
{
	if (DsplyStrk.DsplyFlags.DSplyBlnkTmOut_F)
	{
		DsplyStrk.DsplyVars.DSplyBffr[HrsTenDgt] = CAP_P;
		DsplyStrk.DsplyVars.DSplyBffr[HrsUntDgt] = DsplyNumArr[SystmStrk.SystmVars.ParamNo];
		if (SystmStrk.SystmVars.ParamNo == PARAM_10)
		{
			DsplyStrk.DsplyVars.DSplyBffr[HrsTenDgt] = DSPLYNOP;
			DsplyStrk.DsplyVars.DSplyBffr[HrsUntDgt] = DSPLYNOP;
			if (SystmStrk.SystmFlags.SignBit_F)
			{
				DsplyStrk.DsplyVars.DSplyBffr[HrsUntDgt] = NGTVSIGN;
			}
		}
	}
	else
	{
		if (SystmStrk.SystmVars.ParamNo != PARAM_10)
		{
			DsplyStrk.DsplyVars.DSplyBffr[SystmStrk.SystmVars.ShftKeyCntr] = DSPLYNOP;
		}
		if (SystmStrk.SystmVars.ShftKeyCntr != 1)
		{
			if ((SystmStrk.SystmVars.ParamNo == PARAM_00) || (SystmStrk.SystmVars.ParamNo == PARAM_02) ||
				(SystmStrk.SystmVars.ParamNo == PARAM_06))
			{
				DsplyStrk.DsplyVars.DSplyBffr[MinUntDgt] = DSPLYNOP;
			}
		}
		if (SystmStrk.SystmVars.ParamNo == PARAM_10)
		{
			if (SystmStrk.SystmVars.ShftKeyCntr == 2)
			{
				DsplyStrk.DsplyVars.DSplyBffr[MinUntDgt] = DSPLYNOP;
				DsplyStrk.DsplyVars.DSplyBffr[MinTenDgt] = DSPLYNOP;
			}
			if (SystmStrk.SystmVars.ShftKeyCntr == 3)
			{
				DsplyStrk.DsplyVars.DSplyBffr[SecUntDgt] = DSPLYNOP;
				DsplyStrk.DsplyVars.DSplyBffr[SecTenDgt] = DSPLYNOP;
			}
		}
	}
	if (SystmStrk.SystmFlags.ShftKey_F)
	{
		SystmStrk.SystmFlags.ShftKey_F = False;
		SystmStrk.SystmVars.ShftKeyCntr++;
		if ((SystmStrk.SystmVars.ParamNo < PARAM_03) || (SystmStrk.SystmVars.ParamNo == PARAM_08) ||
			(SystmStrk.SystmVars.ParamNo == PARAM_06))
		{
			if (SystmStrk.SystmVars.ShftKeyCntr == 3)
			{
				SystmStrk.SystmVars.ShftKeyCntr = 1;
			}
		}
		else if (SystmStrk.SystmVars.ParamNo == PARAM_10)
		{
			if (SystmStrk.SystmVars.ShftKeyCntr > 3)
			{
				SystmStrk.SystmVars.ShftKeyCntr = 2;
			}
			if (SystmStrk.SystmVars.ShftKeyCntr == 2)
			{
				OffstCntr  = TenDgt*10;
				OffstCntr += UntDgt;
			}
			if (SystmStrk.SystmVars.ShftKeyCntr == 3)
			{
				OffstCntr  = ScndTenDgt*10;
				OffstCntr += ScndUntDgt;
			}
		}
		else
		{
			if (SystmStrk.SystmVars.ShftKeyCntr > 3)
			{
				SystmStrk.SystmVars.ShftKeyCntr = 1;
			}
			if (SystmStrk.SystmVars.ShftKeyCntr == 2)
			{
				OffstCntr = TenDgt;
			}
			if (SystmStrk.SystmVars.ShftKeyCntr == 3)
			{
				OffstCntr = UntDgt;
			}
		}
	}
	if (SystmStrk.SystmFlags.ExtKey_F)
	{
		SystmStrk.SystmFlags.ExtKey_F 	 = False;
		if (SystmStrk.SystmVars.ParamNo != PARAM_10)
		{
			SystmStrk.SystmFlags.ClckSttng_F = False;
			SystmStrk.SystmVars.ShftKeyCntr  = 0;
			SystmStrk.SystmVars.IncKeyCntr   = 0;
			SystmStrk.SystmVars.ParamNo      = 0;
			SystmStrk.SystmFlags.SignBit_F   = False;
			OffStCnt  = 0;
			OffstCntr = 0;
		}
		else
		{
			SystmStrk.SystmVars.ParamNo 		     = PARAM_00;
			SystmStrk.SystmVars.ClckSttngEvnt        = PARAM_00;
			DsplyStrk.DsplyVars.DSplyBffr[SecTenDgt] = DSPLYNOP;
			DsplyStrk.DsplyVars.DSplyBffr[SecUntDgt] = DSPLYNOP;
			SystmStrk.SystmVars.ShftKeyCntr          = 1;
		}
	}
	switch(SystmStrk.SystmVars.ClckSttngEvnt)
	{
		case CLR_DGIT:
			ClrBffr();
			HAL_GPIO_WritePin(GPIOA, CLCK_PM_PA12_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(GPIOA, CLCK_AM_PA15_Pin, GPIO_PIN_RESET);
			SystmStrk.SystmVars.ShftKeyCntr   = 1;
			SystmStrk.SystmFlags.EntrKey_F    = False;
			SystmStrk.SystmFlags.ExtKey_F     = False;
			SystmStrk.SystmFlags.IncKey_F     = False;
			SystmStrk.SystmFlags.ShftKey_F    = False;
			SystmStrk.SystmVars.ClckSttngEvnt = PARAM_00;
		break;
		case PARAM_00: // Set clock mode.
			if (!SystmStrk.SystmFlags.EntrKey_F)
			{
				if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt12Hrs)
				{
					OffStCnt = __12HRSMD__;
				}
				if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt24Hrs)
				{
					OffStCnt = __24HRSMD__;
				}
				OffstCntr = OffStCnt;
				SystmStrk.SystmVars.ClckSttngEvnt = PARAM_SET;
			}
			else
			{
				SystmStrk.SystmFlags.EntrKey_F      = False;
				SystmStrk.SystmFlags.ParamSet_F     = True;
				DsplyStrk.DsplyFlags.DsplyDlyStrt_F = True;
				SystmStrk.SystmVars.ClckSttngEvnt   = SHW_SUSS;
				if (SystmStrk.SystmVars.ParamVal == __12HRSMD__)
				{
					DateTmStrk.DateTmFlags.Hrs24_12_F = Sclt12Hrs;
					DateTmStrk.DateTmFlags.AmPM_F     = ScltAm;
					if (DateTmStrk.DateTmVars.HrsCntr > 12)
					{
						DateTmStrk.DateTmVars.HrsCntr -= 12;
						DateTmStrk.DateTmFlags.AmPM_F = ScltPm;
					}
					if (DateTmStrk.DateTmVars.HrsCntr == 0)
					{
						DateTmStrk.DateTmVars.HrsCntr = 12;
					}
				}
				if (SystmStrk.SystmVars.ParamVal == __24HRSMD__)
				{
					DateTmStrk.DateTmFlags.Hrs24_12_F = Sclt24Hrs;
					if (DateTmStrk.DateTmFlags.AmPM_F == ScltPm)
					{
						if (DateTmStrk.DateTmVars.HrsCntr < 12)
						{
							DateTmStrk.DateTmVars.HrsCntr += 12;
						}
					}
					if (DateTmStrk.DateTmFlags.AmPM_F == ScltAm)
					{
						if (DateTmStrk.DateTmVars.HrsCntr > 12)
						{
							DateTmStrk.DateTmVars.HrsCntr -= 12;
						}
					}
				}
			}
		break;
		case PARAM_01: // Set Am / Pm.
			if (!SystmStrk.SystmFlags.EntrKey_F)
			{
				OffStCnt = DateTmStrk.DateTmFlags.AmPM_F;
				OffstCntr = OffStCnt;
				SystmStrk.SystmVars.ClckSttngEvnt = PARAM_SET;
			}
			else
			{
				SystmStrk.SystmFlags.EntrKey_F      = False;
				DsplyStrk.DsplyFlags.DsplyDlyStrt_F = True;
				SystmStrk.SystmFlags.ParamSet_F     = True;
				SystmStrk.SystmVars.ClckSttngEvnt   = SHW_SUSS;
				SystmStrk.SystmVars.ParamVal        /= 10;
				if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt12Hrs)
				{
					if (SystmStrk.SystmVars.ParamVal == ScltPm)
					{
						DateTmStrk.DateTmFlags.AmPM_F = ScltPm;
					}
					if (SystmStrk.SystmVars.ParamVal == ScltAm)
					{
						DateTmStrk.DateTmFlags.AmPM_F = ScltAm;
					}
				}
			}
		break;
		case PARAM_02: // Set Hrs.
			if (!SystmStrk.SystmFlags.EntrKey_F)
			{
				HAL_GPIO_WritePin(GPIOA, CLCK_PM_PA12_Pin, GPIO_PIN_RESET);
				HAL_GPIO_WritePin(GPIOA, CLCK_AM_PA15_Pin, GPIO_PIN_RESET);
				if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt12Hrs)
				{
					OffStCnt = __12HRSMD__;
				}
				else
				{
					OffStCnt = (__24HRSMD__ - 1);
				}
				OffstCntr = DateTmStrk.DateTmVars.HrsCntr;
				SystmStrk.SystmVars.ClckSttngEvnt = PARAM_SET;
			}
			else
			{
				DateTmStrk.DateTmVars.HrsCntr       = SystmStrk.SystmVars.ParamVal;
				SystmStrk.SystmFlags.EntrKey_F      = False;
				DsplyStrk.DsplyFlags.DsplyDlyStrt_F = True;
				SystmStrk.SystmFlags.ParamSet_F     = True;
				SystmStrk.SystmVars.ClckSttngEvnt   = SHW_SUSS;
			}
		break;
		case PARAM_03: // Set min.
			if (!SystmStrk.SystmFlags.EntrKey_F)
			{
				OffStCnt  = 9;
				OffstCntr = DateTmStrk.DateTmVars.MinCntr;
				TenDgt 	  = OffstCntr / 10;
				UntDgt    = OffstCntr % 10;
				OffstCntr = TenDgt;
				SystmStrk.SystmVars.ClckSttngEvnt = PARAM_SET;
			}
			else
			{
				if (SystmStrk.SystmVars.ParamVal >= MINT_MIN && SystmStrk.SystmVars.ParamVal <= MINT_MAX)
				{
					SystmStrk.SystmFlags.ParamSet_F = True;
					DateTmStrk.DateTmVars.MinCntr   = SystmStrk.SystmVars.ParamVal;
				}
				SystmStrk.SystmFlags.EntrKey_F      = False;
				DsplyStrk.DsplyFlags.DsplyDlyStrt_F = True;
				SystmStrk.SystmVars.ClckSttngEvnt   = SHW_SUSS;
			}
		break;
		case PARAM_04: // Set sec.
			if (!SystmStrk.SystmFlags.EntrKey_F)
			{
				OffStCnt  = 9;
				OffstCntr = DateTmStrk.DateTmVars.SecCntr;
				TenDgt 	  = OffstCntr / 10;
				UntDgt    = OffstCntr % 10;
				OffstCntr = TenDgt;
				SystmStrk.SystmVars.ClckSttngEvnt = PARAM_SET;
			}
			else
			{
				if (SystmStrk.SystmVars.ParamVal >= SECN_MIN && SystmStrk.SystmVars.ParamVal <= SECN_MAX)
				{
					SystmStrk.SystmFlags.ParamSet_F = True;
					DateTmStrk.DateTmVars.SecCntr   = SystmStrk.SystmVars.ParamVal;
				}
				SystmStrk.SystmFlags.EntrKey_F      = False;
				DsplyStrk.DsplyFlags.DsplyDlyStrt_F = True;
				SystmStrk.SystmVars.ClckSttngEvnt   = SHW_SUSS;
			}
		break;
		case PARAM_05: // Set Date.
			if (!SystmStrk.SystmFlags.EntrKey_F)
			{
				OffStCnt  = 9;
				OffstCntr = DateTmStrk.DateTmVars.DateVal;
				TenDgt 	  = OffstCntr / 10;
				UntDgt    = OffstCntr % 10;
				OffstCntr = TenDgt;
				SystmStrk.SystmVars.ClckSttngEvnt = PARAM_SET;
			}
			else
			{
				SystmStrk.SystmFlags.EntrKey_F = False;
				if (SystmStrk.SystmVars.ParamVal >= DATE_MIN && SystmStrk.SystmVars.ParamVal <= DATE_MAX)
				{
					SystmStrk.SystmFlags.ParamSet_F = True;
					DateTmStrk.DateTmVars.DateVal   = SystmStrk.SystmVars.ParamVal;
				}
				SystmStrk.SystmFlags.EntrKey_F      = False;
				DsplyStrk.DsplyFlags.DsplyDlyStrt_F = True;
				SystmStrk.SystmVars.ClckSttngEvnt   = SHW_SUSS;
			}
		break;
		case PARAM_06: // Set Month.
			if (!SystmStrk.SystmFlags.EntrKey_F)
			{
				OffStCnt  = 12;
				OffstCntr = DateTmStrk.DateTmVars.MnthVal;
				SystmStrk.SystmVars.ClckSttngEvnt = PARAM_SET;
			}
			else
			{
				DateTmStrk.DateTmVars.MnthVal       = SystmStrk.SystmVars.ParamVal;
				SystmStrk.SystmFlags.EntrKey_F      = False;
				SystmStrk.SystmFlags.ParamSet_F     = True;
				DsplyStrk.DsplyFlags.DsplyDlyStrt_F = True;
				SystmStrk.SystmVars.ClckSttngEvnt   = SHW_SUSS;
			}
		break;
		case PARAM_07: // Set Year.
			if (!SystmStrk.SystmFlags.EntrKey_F)
			{
				OffStCnt  = 9;
				OffstCntr = DateTmStrk.DateTmVars.YrsVal;
				TenDgt 	  = OffstCntr / 10;
				UntDgt    = OffstCntr % 10;
				OffstCntr = TenDgt;
				SystmStrk.SystmVars.ClckSttngEvnt = PARAM_SET;
			}
			else
			{
				DateTmStrk.DateTmVars.YrsVal        = SystmStrk.SystmVars.ParamVal;
				SystmStrk.SystmFlags.ParamSet_F     = True;
				SystmStrk.SystmFlags.EntrKey_F      = False;
				DsplyStrk.DsplyFlags.DsplyDlyStrt_F = True;
				SystmStrk.SystmVars.ClckSttngEvnt   = SHW_SUSS;
			}
		break;
		case PARAM_08: // Set week.
			if (!SystmStrk.SystmFlags.EntrKey_F)
			{
				OffStCnt  = 7;
				OffstCntr = DateTmStrk.DateTmVars.DayVal;
				SystmStrk.SystmVars.ClckSttngEvnt = PARAM_SET;
			}
			else
			{
				DateTmStrk.DateTmVars.DayVal        = SystmStrk.SystmVars.ParamVal / 10;
				SystmStrk.SystmFlags.ParamSet_F     = True;
				SystmStrk.SystmFlags.EntrKey_F      = False;
				DsplyStrk.DsplyFlags.DsplyDlyStrt_F = True;
				SystmStrk.SystmVars.ClckSttngEvnt   = SHW_SUSS;
			}
		break;
		case PARAM_09: // Set Slave Id.
			if (!SystmStrk.SystmFlags.EntrKey_F)
			{
				OffStCnt  = 9;
				OffstCntr = SystmStrk.SystmVars.SlvId;
				TenDgt 	  = OffstCntr / 10;
				UntDgt    = OffstCntr % 10;
				OffstCntr = TenDgt;
				SystmStrk.SystmVars.ClckSttngEvnt = PARAM_SET;
			}
			else
			{
				SystmStrk.SystmVars.SlvId  = SystmStrk.SystmVars.ParamVal;
				UrtStrk.UrtVars.UrtBffr[0] = SystmStrk.SystmVars.SlvId;
				HAL_I2C_Mem_Write_IT(&hi2c1, EPROM_ADDRS_W, 0x02, I2C_MEMADD_SIZE_16BIT, UrtStrk.UrtVars.UrtBffr, 1);
				SystmStrk.SystmFlags.ParamSet_F     = True;
				SystmStrk.SystmFlags.EntrKey_F      = False;
				DsplyStrk.DsplyFlags.DsplyDlyStrt_F = True;
				SystmStrk.SystmVars.ClckSttngEvnt   = SHW_SUSS;
			}
		break;
		case PARAM_10: // Set UTC offset.
			if (!SystmStrk.SystmFlags.EntrKey_F)
			{
				OffStCnt   = 14;
				OffstCntr  = DsplyStrk.DsplyVars.HrsUtcOffst;
				ScndTenDgt = DsplyStrk.DsplyVars.MinUtcOffst / 10;
				ScndUntDgt = DsplyStrk.DsplyVars.MinUtcOffst % 10;
				SystmStrk.SystmVars.ClckSttngEvnt = PARAM_SET;
			}
			else
			{
				SystmStrk.SystmFlags.ParamSet_F     = True;
				SystmStrk.SystmFlags.EntrKey_F      = False;
				DsplyStrk.DsplyFlags.DsplyDlyStrt_F = True;
				SystmStrk.SystmVars.ClckSttngEvnt   = SHW_SUSS;
				if (SystmStrk.SystmFlags.SignBit_F)
				{
					DsplyStrk.DsplyVars.HrsUtcOffst = 0 - DsplyStrk.DsplyVars.HrsUtcOffst;
					DsplyStrk.DsplyVars.MinUtcOffst = 0 - DsplyStrk.DsplyVars.MinUtcOffst;
				}
				UrtStrk.UrtVars.UrtBffr[0] = DsplyStrk.DsplyVars.HrsUtcOffst;
				UrtStrk.UrtVars.UrtBffr[1] = DsplyStrk.DsplyVars.MinUtcOffst;
				HAL_I2C_Mem_Write_IT(&hi2c1, EPROM_ADDRS_W, 0x00, I2C_MEMADD_SIZE_16BIT, UrtStrk.UrtVars.UrtBffr, 2);
				DsplyStrk.DsplyVars.DSplyBffr[SecTenDgt] = DSPLYNOP;
				DsplyStrk.DsplyVars.DSplyBffr[SecUntDgt] = DSPLYNOP;
				DsplyStrk.DsplyVars.DSplyBffr[HrsUntDgt] = DSPLYNOP;
			}
		break;
		case SHW_SUSS:
			if (SystmStrk.SystmFlags.ParamSet_F)
			{
				DsplyStrk.DsplyVars.DSplyBffr[HrsTenDgt] = FIVE;
				DsplyStrk.DsplyVars.DSplyBffr[HrsUntDgt] = CAP_A;
				DsplyStrk.DsplyVars.DSplyBffr[MinTenDgt] = CAP_U;
				DsplyStrk.DsplyVars.DSplyBffr[MinUntDgt] = CAP_E;
				if (SystmStrk.SystmVars.ParamNo < PARAM_09)
				{
					SetDateTime();
					DateTmStrk.DateTmFlags.WrtDateTm_F = True;
				}
			}
			else
			{
				DsplyStrk.DsplyVars.DSplyBffr[HrsTenDgt] = CAP_E;
				DsplyStrk.DsplyVars.DSplyBffr[HrsUntDgt] = SML_L_O;
				DsplyStrk.DsplyVars.DSplyBffr[MinTenDgt] = SML_R;
				DsplyStrk.DsplyVars.DSplyBffr[MinUntDgt] = SML_R;
			}
			if (SystmStrk.SystmFlags.I2c_TxCmplt_F)
			{
				SystmStrk.SystmFlags.I2c_TxCmplt_F = False;
			}
			if (DsplyStrk.DsplyFlags.DsplyDlyTmOut_F)
			{
				SystmStrk.SystmFlags.ParamSet_F      = False;
				DsplyStrk.DsplyFlags.DsplyDlyTmOut_F = False;
				SystmStrk.SystmVars.ClckSttngEvnt    = SystmStrk.SystmVars.ParamNo;
				SystmStrk.SystmVars.ShftKeyCntr      = 1;
			}
		break;
		case PARAM_SET:
			if (SystmStrk.SystmFlags.IncKey_F)
			{
				SystmStrk.SystmFlags.IncKey_F = False;
				if (SystmStrk.SystmVars.ShftKeyCntr == 1)
				{
					SystmStrk.SystmVars.ParamNo++;
					if (SystmStrk.SystmVars.ParamNo > PARAM_10)
					{
						SystmStrk.SystmVars.ParamNo = PARAM_00;
					}
					SystmStrk.SystmVars.ClckSttngEvnt = SystmStrk.SystmVars.ParamNo;
					if (SystmStrk.SystmVars.ParamNo == PARAM_10)
					{
						SystmStrk.SystmVars.ShftKeyCntr = 2;
					}
				}
				else
				{
					OffstCntr++;
				}
			}
			if ((SystmStrk.SystmVars.ParamNo != PARAM_00) && (SystmStrk.SystmVars.ParamNo != PARAM_01) &&
				(SystmStrk.SystmVars.ParamNo != PARAM_06) && (SystmStrk.SystmVars.ParamNo != PARAM_08) &&
				(SystmStrk.SystmVars.ParamNo != PARAM_10))
			{
				if (OffstCntr > OffStCnt)
				{
					if (OffStCnt == 12)
					{
						OffstCntr = 1;
					}
					else
					{
						OffstCntr = 0;
					}
				}
				if (SystmStrk.SystmVars.ParamNo != PARAM_02)
				{
					if (SystmStrk.SystmVars.ShftKeyCntr == 2)
					{
						TenDgt = OffstCntr;
					}
					if (SystmStrk.SystmVars.ShftKeyCntr == 3)
					{
						UntDgt = OffstCntr;
					}
				}
				else
				{
					TenDgt = OffstCntr / 10;
					UntDgt = OffstCntr % 10;
				}
			}
			if (SystmStrk.SystmVars.ParamNo == PARAM_00)
			{
				if (OffstCntr == 13)
				{
					OffstCntr = 24;
				}
				if (OffstCntr == 25)
				{
					OffstCntr = 12;
				}
				TenDgt = OffstCntr / 10;
				UntDgt = OffstCntr % 10;
			}
			if (SystmStrk.SystmVars.ParamNo == PARAM_01)
			{
				if (OffstCntr >= 2)
				{
					OffstCntr = 0;
				}
				UntDgt = 0;
				TenDgt = OffstCntr;
			}
			if (SystmStrk.SystmVars.ParamNo == PARAM_06)
			{
				if (OffstCntr > 12)
				{
					OffstCntr = 1;
				}
				TenDgt = OffstCntr / 10;
				UntDgt = OffstCntr % 10;
			}
			if (SystmStrk.SystmVars.ParamNo == PARAM_08)
			{
				if (OffstCntr > 7)
				{
					OffstCntr = 1;
				}
				TenDgt = OffstCntr;
			}
			if (SystmStrk.SystmVars.ParamNo == PARAM_10)
			{
				if (SystmStrk.SystmVars.ShftKeyCntr == 2)
				{
					if (OffstCntr > OffStCnt)
					{
						OffstCntr = 1;
						SystmStrk.SystmFlags.SignBit_F = True;
					}
					if (SystmStrk.SystmFlags.SignBit_F)
					{
						if (OffstCntr > 12)
						{
							OffstCntr = 0;
							SystmStrk.SystmFlags.SignBit_F = False;
						}
					}
					TenDgt = OffstCntr / 10;
					UntDgt = OffstCntr % 10;
				}
				if (SystmStrk.SystmVars.ShftKeyCntr == 3)
				{
					if (OffstCntr == 1)
					{
						OffstCntr = 30;
					}
					if (OffstCntr == 31)
					{
						OffstCntr = 45;
					}
					if (OffstCntr == 46)
					{
						OffstCntr = 0;
					}
					ScndTenDgt = OffstCntr / 10;
					ScndUntDgt = OffstCntr % 10;
				}
			}
			if (DsplyStrk.DsplyFlags.DSplyBlnkTmOut_F)
			{
				DsplyStrk.DsplyVars.DSplyBffr[MinTenDgt] = DsplyNumArr[TenDgt];
				DsplyStrk.DsplyVars.DSplyBffr[MinUntDgt] = DsplyNumArr[UntDgt];
				if (SystmStrk.SystmVars.ParamNo == PARAM_10)
				{
					DsplyStrk.DsplyVars.DSplyBffr[SecTenDgt] = DsplyNumArr[ScndTenDgt];
					DsplyStrk.DsplyVars.DSplyBffr[SecUntDgt] = DsplyNumArr[ScndUntDgt];
				}
			}
			if (SystmStrk.SystmVars.ParamNo == PARAM_01)
			{
				if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt24Hrs)
				{
					HAL_GPIO_WritePin(GPIOA, CLCK_PM_PA12_Pin, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOA, CLCK_AM_PA15_Pin, GPIO_PIN_RESET);
				}
				if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt12Hrs)
				{
					if (OffstCntr)
					{
						HAL_GPIO_WritePin(GPIOA, CLCK_AM_PA15_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(GPIOA, CLCK_PM_PA12_Pin, GPIO_PIN_RESET);
					}
					else
					{
						HAL_GPIO_WritePin(GPIOA, CLCK_PM_PA12_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(GPIOA, CLCK_AM_PA15_Pin, GPIO_PIN_RESET);
					}
				}
				DsplyStrk.DsplyVars.DSplyBffr[MinUntDgt] = DSPLYNOP;
			}
			if (SystmStrk.SystmVars.ParamNo == PARAM_08)
			{
				DsplyStrk.DsplyVars.DSplyBffr[MinUntDgt] = DSPLYNOP;
			}
			if (SystmStrk.SystmFlags.EntrKey_F)
			{
				SystmStrk.SystmVars.ClckSttngEvnt = SystmStrk.SystmVars.ParamNo;
				SystmStrk.SystmVars.ParamVal      = TenDgt * 10;
				SystmStrk.SystmVars.ParamVal     += UntDgt;
				if (SystmStrk.SystmVars.ParamNo == PARAM_10)
				{
					DsplyStrk.DsplyVars.HrsUtcOffst  = TenDgt * 10;
					DsplyStrk.DsplyVars.HrsUtcOffst += UntDgt;
					DsplyStrk.DsplyVars.MinUtcOffst  = ScndTenDgt * 10;
					DsplyStrk.DsplyVars.MinUtcOffst += ScndUntDgt;
					SystmStrk.SystmVars.ShftKeyCntr  = 2;
				}
			}
		break;
	}
}

void AddUtcOffst_ToLclTim(void)
{
	if ((UrtStrk.UrtVars.UTcHrs + DsplyStrk.DsplyVars.HrsUtcOffst) < 0)
	{
		UrtStrk.UrtVars.UTcHrs += 24;
		UrtStrk.UrtVars.UTcHrs += DsplyStrk.DsplyVars.HrsUtcOffst;
		DateTmStrk.DateTmVars.DateVal--;
		DateTmStrk.DateTmVars.DayVal--;
	}
	else
	{
		UrtStrk.UrtVars.UTcHrs += DsplyStrk.DsplyVars.HrsUtcOffst;
	}
	if ((DsplyStrk.DsplyVars.MinUtcOffst + UrtStrk.UrtVars.UtcMin) < 0)
	{
		UrtStrk.UrtVars.UtcMin += 60;
		UrtStrk.UrtVars.UtcMin += DsplyStrk.DsplyVars.MinUtcOffst;
		UrtStrk.UrtVars.UTcHrs--;
	}
	else
	{
		UrtStrk.UrtVars.UtcMin += DsplyStrk.DsplyVars.MinUtcOffst;
	}
	if (UrtStrk.UrtVars.UtcMin >= 60)
	{
		UrtStrk.UrtVars.UtcMin -= 60;
		UrtStrk.UrtVars.UTcHrs++;
	}

	DateTmStrk.DateTmVars.MinCntr = UrtStrk.UrtVars.UtcMin;

	if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt12Hrs)
	{
		if (UrtStrk.UrtVars.UTcHrs > __12HRSMD__)
		{
			DateTmStrk.DateTmVars.HrsCntr = UrtStrk.UrtVars.UTcHrs - __12HRSMD__;
			DateTmStrk.DateTmFlags.AmPM_F = ScltPm;
		}
		else
		{
			DateTmStrk.DateTmFlags.AmPM_F = ScltAm;
			DateTmStrk.DateTmVars.HrsCntr = UrtStrk.UrtVars.UTcHrs;
			if (UrtStrk.UrtVars.UTcHrs == 0)
			{
				DateTmStrk.DateTmVars.HrsCntr = 12;
			}
		}
	}
	if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt24Hrs)
	{
		DateTmStrk.DateTmVars.HrsCntr = UrtStrk.UrtVars.UTcHrs;
	}
}

/**
 * @brief  : Display clock hrs, min, sec, date,month, year, clcok mode, Am/Pm.
 * Turn setting on when shift and increase key hold for 10 sec.
 * @param  : None.
 * @retval : None.
**/
void DsplyClck_Mth(void)
{
	DsplyStrk.DsplyVars.DSplyBffr[HrsTenDgt] = DsplyNumArr[DateTmStrk.DateTmVars.HrsCntr / 10];  // 0
	DsplyStrk.DsplyVars.DSplyBffr[HrsUntDgt] = DsplyNumArr[DateTmStrk.DateTmVars.HrsCntr % 10];  // 1
	DsplyStrk.DsplyVars.DSplyBffr[MinTenDgt] = DsplyNumArr[DateTmStrk.DateTmVars.MinCntr / 10];  // 2
	DsplyStrk.DsplyVars.DSplyBffr[MinUntDgt] = DsplyNumArr[DateTmStrk.DateTmVars.MinCntr % 10];  // 3
	DsplyStrk.DsplyVars.DSplyBffr[SecTenDgt] = DsplyNumArr[DateTmStrk.DateTmVars.SecCntr / 10];  // 4
	DsplyStrk.DsplyVars.DSplyBffr[SecUntDgt] = DsplyNumArr[DateTmStrk.DateTmVars.SecCntr % 10];  // 5
	DsplyStrk.DsplyVars.DSplyBffr[DateTenDgt] = DsplyNumArr[DateTmStrk.DateTmVars.DateVal / 10];  // 6
	DsplyStrk.DsplyVars.DSplyBffr[DateUntDgt] = DsplyNumArr[DateTmStrk.DateTmVars.DateVal % 10];  // 7
	DsplyStrk.DsplyVars.DSplyBffr[MnthTenDgt] = DsplyNumArr[DateTmStrk.DateTmVars.MnthVal / 10];  // 8
	DsplyStrk.DsplyVars.DSplyBffr[MnthUntDgt] = DsplyNumArr[DateTmStrk.DateTmVars.MnthVal % 10];  // 9
	DsplyStrk.DsplyVars.DSplyBffr[YearTenDgt] = DsplyNumArr[DateTmStrk.DateTmVars.YrsVal  / 10];  // 10
	DsplyStrk.DsplyVars.DSplyBffr[YearUntDgt] = DsplyNumArr[DateTmStrk.DateTmVars.YrsVal  % 10];  // 11
	if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt24Hrs)
	{
		HAL_GPIO_WritePin(GPIOA, CLCK_AM_PA15_Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOA, CLCK_PM_PA12_Pin, GPIO_PIN_RESET);
	}
	if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt12Hrs)
	{
		if (DateTmStrk.DateTmFlags.AmPM_F == ScltPm)
		{
			HAL_GPIO_WritePin(GPIOA, CLCK_AM_PA15_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA, CLCK_PM_PA12_Pin, GPIO_PIN_RESET);
		}
		else
		{
			HAL_GPIO_WritePin(GPIOA, CLCK_PM_PA12_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin(GPIOA, CLCK_AM_PA15_Pin, GPIO_PIN_RESET);
		}
	}
}

void G_SetData_Mth(void)
{
	uint8_t BitCntr = 0;
	HAL_GPIO_WritePin(GPIOC, STCP_PC14_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOC, SHCP_PC15_Pin, GPIO_PIN_RESET);
	for(; BitCntr < 16; BitCntr++)
	{
		if ((SgmntUn.SgmntVar & (1 << BitCntr)))
		{
			HAL_GPIO_WritePin(GPIOC, DS_PC13_Pin, GPIO_PIN_SET);
		}
		else
		{
			HAL_GPIO_WritePin(GPIOC, DS_PC13_Pin, GPIO_PIN_RESET);
		}
		asm("NOP");
		asm("NOP");
		HAL_GPIO_WritePin(GPIOC, SHCP_PC15_Pin, GPIO_PIN_RESET);
		asm("NOP");
		asm("NOP");
		HAL_GPIO_WritePin(GPIOC, SHCP_PC15_Pin, GPIO_PIN_SET);
	}
	asm("NOP");
	asm("NOP");
	HAL_GPIO_WritePin(GPIOC, STCP_PC14_Pin, GPIO_PIN_RESET);
	asm("NOP");
	asm("NOP");
	HAL_GPIO_WritePin(GPIOC, STCP_PC14_Pin, GPIO_PIN_SET);
}

void SwtchDsply(void)
{
	SystmStrk.SystmVars.MaskPrt    = GPIOA->ODR & 0xFFFF00;
//	GPIOA->ODR 					   = SystmStrk.SystmVars.MaskPrt;
	SgmntUn.SgmntVar 			   = 0xFFFF;
	SgmntUn.SgmntFlags.Clck_Hrst_F = DsplyStrk.DsplyFlags.ClckHrt_F;
	SgmntUn.SgmntFlags.SvntDsply   = DsplyStrk.DsplyFlags.ClckHrt_F;
	SgmntUn.SgmntFlags.GpsAtcv_F   = DsplyStrk.DsplyFlags.GpsSgnlLed_F;
	switch (DsplyStrk.DsplyVars.DSplySwtchEvnt)
	{
		case HRSTEN_DGT:
			SystmStrk.SystmVars.MaskPrt     |= DsplyStrk.DsplyVars.DSplyBffr[HrsTenDgt];
			SgmntUn.SgmntFlags.HrsTenSgmnt_F = False;
		break;
		case HRSUNT_DGT:
			SystmStrk.SystmVars.MaskPrt     |= DsplyStrk.DsplyVars.DSplyBffr[HrsUntDgt];
			SgmntUn.SgmntFlags.HrsUntSgmnt_F = False;
		break;
		case MINTEN_DGT:
			SystmStrk.SystmVars.MaskPrt     |= DsplyStrk.DsplyVars.DSplyBffr[MinTenDgt];
			SgmntUn.SgmntFlags.MinTenSgmnt_F = False;
		break;
		case MINUNT_DGT:
			SystmStrk.SystmVars.MaskPrt     |= DsplyStrk.DsplyVars.DSplyBffr[MinUntDgt];
			SgmntUn.SgmntFlags.MinUntSgmnt_F = False;
		break;
		case SECTEN_DGT:
			SystmStrk.SystmVars.MaskPrt     |= DsplyStrk.DsplyVars.DSplyBffr[SecTenDgt];
			SgmntUn.SgmntFlags.SecTenSgmnt_F = False;
		break;
		case SECUNT_DGT:
			if (nRF24Strk.nRFFlags.nRFBlnk_F)
			{
				nRF24Strk.nRFFlags.nRFBlnk_F = False;
				SystmStrk.SystmVars.MaskPrt |= DsplyStrk.DsplyVars.DSplyBffr[SecUntDgt] | DOT;
			}
			else
			{
				SystmStrk.SystmVars.MaskPrt |= DsplyStrk.DsplyVars.DSplyBffr[SecUntDgt];
			}
			SgmntUn.SgmntFlags.SecUntSgmnt_F = False;
		break;
		case DATETEN_DGT:
			SystmStrk.SystmVars.MaskPrt  	 |= DsplyStrk.DsplyVars.DSplyBffr[DateTenDgt];
			SgmntUn.SgmntFlags.DateTenSgmnt_F = False;
		break;
		case DATEUNT_DGT:
			SystmStrk.SystmVars.MaskPrt      |= DsplyStrk.DsplyVars.DSplyBffr[DateUntDgt];
			SgmntUn.SgmntFlags.DateUntSgmnt_F = False;
		break;
		case MNTHTEN_DGT:
			SystmStrk.SystmVars.MaskPrt  	 |= DsplyStrk.DsplyVars.DSplyBffr[MnthTenDgt];
			SgmntUn.SgmntFlags.MnthTenSgmnt_F = False;
		break;
		case MNTHUNT_DGT:
			SystmStrk.SystmVars.MaskPrt  	 |= DsplyStrk.DsplyVars.DSplyBffr[MnthUntDgt];
			SgmntUn.SgmntFlags.MnthUntSgmnt_F = False;
		break;
		case YEARTEN_DGT:
			SystmStrk.SystmVars.MaskPrt  	 |= DsplyStrk.DsplyVars.DSplyBffr[YearTenDgt];
			SgmntUn.SgmntFlags.YearTenSgmnt_F = False;
		break;
		case YEARUNT_DGT:
			/*if (nRF24Strk.nRFFlags.nRFBlnk_F)
			{
				nRF24Strk.nRFFlags.nRFBlnk_F = False;
				SystmStrk.SystmVars.MaskPrt |= DsplyStrk.DsplyVars.DSplyBffr[YearUntDgt] | DOT;
			}
			else
			{
			}*/
			SystmStrk.SystmVars.MaskPrt |= DsplyStrk.DsplyVars.DSplyBffr[YearUntDgt];
			SgmntUn.SgmntFlags.YearUntSgmnt_F    = False;
			DsplyStrk.DsplyFlags.DsplyWrtCmplt_F = True;
			DsplyStrk.DsplyVars.DSplySwtchEvnt   = 0;
		break;
	}
	G_SetData_Mth();
	GPIOA->ODR = SystmStrk.SystmVars.MaskPrt;
	DsplyStrk.DsplyVars.DSplySwtchEvnt++;
}

void ClrBffr(void)
{
	uint8_t BffrCntr = 4;
	for (; BffrCntr < 12; BffrCntr++)
	{
		DsplyStrk.DsplyVars.DSplyBffr[BffrCntr] = 0;
	}
}
