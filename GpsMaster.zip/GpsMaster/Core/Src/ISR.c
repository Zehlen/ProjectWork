/*
 * ISR.c
 *
 *  Created on: 03-Sept-2026
 *      Author: Malcolm.X
 */

#include "ISR.h"

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if (htim->Instance == TIM3)
	{
		DateTmStrk.DateTmVars.MillSecCntr++;
/*------------------------------ Sec Counter---------------------------------------------*/
		if (DateTmStrk.DateTmVars.MillSecCntr > SECDLY_CNT)
		{
			DateTmStrk.DateTmVars.MillSecCntr = 0;
			if ((SystmStrk.SystmFlags.IncKey_F && SystmStrk.SystmFlags.ShftKey_F))
			{
				SystmStrk.SystmVars.ClckSttngCntr++;
				if (SystmStrk.SystmVars.ClckSttngCntr > STTNGDLY_CNT)
				{
					if ((GPIOB->IDR & SHFT_PB1_Pin) == (uint32_t)GPIO_PIN_RESET && ((GPIOB->IDR & INC_PB4_Pin) == (uint32_t)GPIO_PIN_RESET))
					{
						SystmStrk.SystmVars.ClckSttngCntr  = 0;
						SystmStrk.SystmFlags.ShftKey_F 	   = False;
						SystmStrk.SystmFlags.IncKey_F  	   = False;
						SystmStrk.SystmFlags.ClckSttng_F   = True;
					}
				}
				if (SystmStrk.SystmVars.ClckSttngCntr < STTNGDLY_CNT)
				{
					if (((GPIOB->IDR & SHFT_PB1_Pin) != (uint32_t)GPIO_PIN_RESET) || (((GPIOB->IDR & INC_PB4_Pin) != (uint32_t)GPIO_PIN_RESET)))
					{
						SystmStrk.SystmFlags.ShftKey_F 	  = False;
						SystmStrk.SystmFlags.IncKey_F  	  = False;
						SystmStrk.SystmVars.ClckSttngCntr = 0;
					}
				}
			}
			if (DsplyStrk.DsplyFlags.DsplyDlyStrt_F)
			{
				DsplyStrk.DsplyVars.DsplyDlyCntr++;
				if (DsplyStrk.DsplyVars.DsplyDlyCntr > DSPLYDLY_CNT)
				{
					DsplyStrk.DsplyVars.DsplyDlyCntr 	 = 0;
					DsplyStrk.DsplyFlags.DsplyDlyTmOut_F = True;
					DsplyStrk.DsplyFlags.DsplyDlyStrt_F  = False;
				}
			}
			if (SystmStrk.SystmFlags.StrtTrsnmt_F)
			{
				SystmStrk.SystmVars.DataTrsnmtCntr++;
				if (SystmStrk.SystmVars.DataTrsnmtCntr > 1)
				{
					SystmStrk.SystmVars.DataTrsnmtCntr = 0;
					DateTmStrk.DateTmFlags.WrtDateTm_F = True;
					SystmStrk.SystmFlags.StrtTrsnmt_F  = False;
				}
			}
		}
/*------------------------------ Sec Counter end ------------------------------------------*/
		/*if (UrtStrk.UrtFlags.MdbsDlyStrt_F)
		{
			UrtStrk.UrtVars.MdbDlyCntr++;
			if (UrtStrk.UrtVars.MdbDlyCntr > 199)
			{
				UrtStrk.UrtVars.MdbDlyCntr 	    = 0;
				UrtStrk.UrtFlags.MdbsDlyTmOut_F = True;
			}
		}*/
		if (SystmStrk.SystmFlags.ClckDlyStrt_F)
		{
			SystmStrk.SystmVars.ClckDlyCntr++;
			if (SystmStrk.SystmVars.ClckDlyCntr > CLCKDLY_CNT)
			{
				SystmStrk.SystmVars.ClckDlyCntr 	= 0;
				SystmStrk.SystmFlags.ClckDlyTmOut_F = True;
				SystmStrk.SystmFlags.ClckDlyStrt_F  = False;
			}
		}
		if (UrtStrk.UrtFlags.GpsDlyStrt_F)
		{
			UrtStrk.UrtVars.GpsDlyCntr++;
			if (UrtStrk.UrtVars.GpsDlyCntr > UrtStrk.UrtVars.GpsDlyCnt)
			{
				UrtStrk.UrtVars.GpsDlyCntr     = 0;
				UrtStrk.UrtFlags.GpsDlyStrt_F  = False;
				UrtStrk.UrtFlags.GpsDlyTmOut_F = True;
				UrtStrk.UrtFlags.GpsRxCmplt_F  = True;
			}
		}
		if (SystmStrk.SystmFlags.KeyPrss_F)
		{
			SystmStrk.SystmVars.KeyDlyCntr++;
			if (SystmStrk.SystmVars.KeyDlyCntr > DBUNCDLY_CNT)
			{
				SystmStrk.SystmVars.KeyDlyCntr = 0;
				SystmStrk.SystmFlags.KeyPrss_F = False;
				if (SystmStrk.SystmVars.KeyVals == ENTR_PB0_Pin)
				{
					if ((GPIOB->IDR & SystmStrk.SystmVars.KeyVals) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.EntrKey_F = True;
					}
				}
				if (SystmStrk.SystmVars.KeyVals == SHFT_PB1_Pin)
				{
					if ((GPIOB->IDR & SystmStrk.SystmVars.KeyVals) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.ShftKey_F = True;
					}
					if ((GPIOB->IDR & INC_PB4_Pin) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.IncKey_F = True;
					}
				}
				if (SystmStrk.SystmVars.KeyVals == INC_PB4_Pin)
				{
					if ((GPIOB->IDR & SystmStrk.SystmVars.KeyVals) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.IncKey_F = True;
					}
					if ((GPIOB->IDR & SHFT_PB1_Pin) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.ShftKey_F = True;
					}
				}
				if (SystmStrk.SystmVars.KeyVals == EXT_PB3_Pin)
				{
					if ((GPIOB->IDR & SystmStrk.SystmVars.KeyVals) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.ExtKey_F = True;
					}
				}
			}
		}
		if (DsplyStrk.DsplyFlags.DsplBlnkStrt_F)
		{
			DsplyStrk.DsplyVars.DsplyBlnkCntr++;
			if (DsplyStrk.DsplyVars.DsplyBlnkCntr > DSPLYBLNK_CNT)
			{
				DsplyStrk.DsplyVars.DsplyBlnkCntr 	  = 0;
				DsplyStrk.DsplyFlags.DSplyBlnkTmOut_F = ~DsplyStrk.DsplyFlags.DSplyBlnkTmOut_F;
			}
		}
		if (SystmStrk.SystmFlags.ClckHrtBlnkStrt_F)
		{
			DsplyStrk.DsplyFlags.ClckHrt_F = False;
			if (DateTmStrk.DateTmVars.MillSecCntr > CLCKHRTDLY_CNT)
			{
				DsplyStrk.DsplyFlags.ClckHrt_F = True;
			}
		}
		if (SystmStrk.SystmFlags.GpsSnglActv_F)
		{
			SystmStrk.SystmVars.GpsSnglCntr++;
			if (SystmStrk.SystmVars.GpsSnglCntr > GPSSGNLLED_CNT)
			{
				SystmStrk.SystmVars.GpsSnglCntr   = 0;
				DsplyStrk.DsplyFlags.GpsSgnlLed_F = ~ DsplyStrk.DsplyFlags.GpsSgnlLed_F;
			}
		}
		else
		{
			DsplyStrk.DsplyFlags.GpsSgnlLed_F = False;
		}
		if (SystmStrk.SystmFlags.WtchCntrStrt_F)
		{
			SystmStrk.SystmVars.WtchCntr++;
			if (!DsplyStrk.DsplyFlags.DsplyWrtCmplt_F)
			{
				if (SystmStrk.SystmVars.WtchCntr > 999)
				{
					DsplyStrk.DsplyFlags.DsplyWrtCmplt_F = True;
					SystmStrk.SystmFlags.I2c_RxCmplt_F   = True;
				}
			}
			if (!UrtStrk.UrtFlags.GpsDlyStrt_F)
			{
				if (SystmStrk.SystmVars.WtchCntr > 999)
				{
					UrtStrk.UrtFlags.GpsDlyStrt_F = True;
				}
			}
			if (!nRF24Strk.nRFFlags.nRFTxCmplt_F)
			{
				if (SystmStrk.SystmVars.WtchCntr > 999)
				{
					nRF24Strk.nRFFlags.nRFTxCmplt_F = True;
				}
			}
			if (SystmStrk.SystmVars.WtchCntr > 999)
			{
				SystmStrk.SystmVars.WtchCntr = 0;
			}
		}
		DsplyStrk.DsplyFlags.DsplySwTmOt_F = True;
	}
}

void HAL_I2C_MemTxCpltCallback(I2C_HandleTypeDef *hi2c)
{
//	DsplyStrk.DsplyFlags.DsplyWrtCmplt_F = True;
	SystmStrk.SystmFlags.I2c_TxCmplt_F   = True;
}

void HAL_I2C_MemRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
//	DsplyStrk.DsplyFlags.DsplyWrtCmplt_F = True;
	SystmStrk.SystmFlags.I2c_RxCmplt_F   = True;
}

void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c)
{
	asm("NOP");
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if (huart->Instance == USART1)
	{
		UrtStrk.UrtFlags.MdbsRxCmplt_F = True;
	}
	if (huart->Instance == USART3)
	{
		UrtStrk.UrtFlags.GpsRxCmplt_F  = True;
	}
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	if (huart->Instance == USART1)
	{
		UrtStrk.UrtFlags.MdbsTxCmplt_F = True;
//		nRF24Strk.nRFFlags.nRFBlnk_F   = True;
	}
	if (huart->Instance == USART3)
	{
		UrtStrk.UrtFlags.GpsTxCmplt_F = True;
	}
}

void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi)
{
	nRF24Strk.nRFFlags.nRFTxCmplt_F = True;
	CSN_HIGH();
}

void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi)
{
	asm("NOP");
}

void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
	nRF24Strk.nRFFlags.nRFRxTxCmplt_F = True;
	CSN_HIGH();
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	SystmStrk.SystmFlags.KeyPrss_F = True;
	SystmStrk.SystmVars.KeyVals    = (uint8_t)GPIO_Pin;
}
