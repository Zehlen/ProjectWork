
#include "nRF.h"

_nRF24Strk nRF24Strk;

void Init_nRF24(void)
{
	if (nRF24Strk.nRFFlags.nRFTxCmplt_F)
	{
		nRF24Strk.nRFFlags.nRFTxCmplt_F = False;
		switch(nRF24Strk.nRFVars.nRFInitEvnt)
		{
			case CONFIG_REG_ADDRS:
				nRF24Strk.nRFVars.nRFCmdBffr[0] = WRT_REG_CMD | CONFIG_REG_ADDRS;
				nRF24Strk.nRFVars.nRFCmdBffr[1] = 0x02; // Enable Tx mode only.
				nRF24Strk.nRFVars.nRFInitEvnt   = ENAA_REG_ADDRS;
				nRF_SetCmd(2);
			break;
			case ENAA_REG_ADDRS:
				CE_LOW();
				nRF24Strk.nRFVars.nRFCmdBffr[0] = WRT_REG_CMD | ENAA_REG_ADDRS;
				nRF24Strk.nRFVars.nRFCmdBffr[1] = 0x00; // Disable autack for pipe0.
				nRF24Strk.nRFVars.nRFInitEvnt   = SETUP_RETR_REG_ADDRS;
				nRF_SetCmd(2);
			break;
			/*case EN_RXADDR_ADDRS:
				Nrf24Strk.NrfVars.NrfBuffr[0] = WRT_REG_CMD | EN_RXADDR_ADDRS;
				Nrf24Strk.NrfVars.NrfBuffr[1] = 0x01;
				Nrf24Strk.NrfVars.NrfInitEvnt = SETUP_AW_REG_ADDRS;
				Nrf_Tx_Data(2);
			break;*/
			/*case SETUP_AW_REG_ADDRS:
				Nrf24Strk.NrfVars.NrfBuffr[0] = WRT_REG_CMD | SETUP_AW_REG_ADDRS;
				Nrf24Strk.NrfVars.NrfBuffr[1] = 0x03;
				Nrf24Strk.NrfVars.NrfInitEvnt = RF_CH_REG_ADDRS;
				Nrf_Tx_Data(2);*/
			break;
			case SETUP_RETR_REG_ADDRS:
				nRF24Strk.nRFVars.nRFCmdBffr[0] = WRT_REG_CMD | SETUP_RETR_REG_ADDRS;
				nRF24Strk.nRFVars.nRFCmdBffr[1] = 0x00; // Auto retransmite disable.
				nRF24Strk.nRFVars.nRFInitEvnt   = RF_CH_REG_ADDRS;
				nRF_SetCmd(2);
			break;
			case RF_CH_REG_ADDRS:
				nRF24Strk.nRFVars.nRFCmdBffr[0] = WRT_REG_CMD | RF_CH_REG_ADDRS;
				nRF24Strk.nRFVars.nRFCmdBffr[1] = 0x4c; // Set frequency 2476 MHz.
				nRF24Strk.nRFVars.nRFInitEvnt   = RF_SETUP_REG_ADDRS;
				nRF_SetCmd(2);
			break;
			case RF_SETUP_REG_ADDRS:
				nRF24Strk.nRFVars.nRFCmdBffr[0] = WRT_REG_CMD | RF_SETUP_REG_ADDRS;
				nRF24Strk.nRFVars.nRFCmdBffr[1] = 0x06; // 0 LNA gain ,RF power output 0dBm, Air data rate = 1Mbps.
				nRF24Strk.nRFVars.nRFInitEvnt   = TX_ADDR_REG_ADDRS;
				nRF_SetCmd(2);
			break;
			/*case RX_ADDR_P0_REG_ADDRS:
				Nrf24Strk.NrfVars.NrfBuffr[0] = WRT_REG_CMD | RX_ADDR_P0_REG_ADDRS;
				Nrf24Strk.NrfVars.NrfBuffr[1] = 0xE7;
				Nrf24Strk.NrfVars.NrfBuffr[2] = 0xE7;
				Nrf24Strk.NrfVars.NrfBuffr[3] = 0xE7;
				Nrf24Strk.NrfVars.NrfBuffr[4] = 0xE7;
				Nrf24Strk.NrfVars.NrfBuffr[5] = 0xE7;
				Nrf24Strk.NrfVars.NrfInitEvnt = TX_ADDR_REG_ADDRS;
				Nrf_Tx_Data(6);
			break;*/
			case TX_ADDR_REG_ADDRS:
				nRF24Strk.nRFVars.nRFCmdBffr[0] = WRT_REG_CMD | TX_ADDR_REG_ADDRS;
				nRF24Strk.nRFVars.nRFCmdBffr[1] = 0xE7; // pipe0 address.
				nRF24Strk.nRFVars.nRFCmdBffr[2] = 0xE7; //
				nRF24Strk.nRFVars.nRFCmdBffr[3] = 0xE7; //
				nRF24Strk.nRFVars.nRFCmdBffr[4] = 0xE7; //
				nRF24Strk.nRFVars.nRFCmdBffr[5] = 0xE7; //
				nRF24Strk.nRFVars.nRFInitEvnt   = FEATURE_REG_ADDRS;
				nRF_SetCmd(6);
			break;
			/*case RX_PW_P0_REG_ADDRS:
				Nrf24Strk.NrfVars.NrfBuffr[0] = WRT_REG_CMD | RX_PW_P0_REG_ADDRS;
				Nrf24Strk.NrfVars.NrfBuffr[1] = 0x08;     // Rx payload size.
				Nrf24Strk.NrfVars.NrfInitEvnt = FEATURE_REG_ADDRS;
				Nrf_Tx_Data(2);
			break;*/
			case FEATURE_REG_ADDRS:
				nRF24Strk.nRFVars.nRFCmdBffr[0] = WRT_REG_CMD | FEATURE_REG_ADDRS;
				nRF24Strk.nRFVars.nRFCmdBffr[1] = 0x00; // Disable Tx paylod Ack, Disable dynamic payload.
				nRF24Strk.nRFVars.nRFInitEvnt   = FLUSH_TX;
				nRF_SetCmd(2);
			break;
			case FLUSH_TX:
				nRF24Strk.nRFVars.nRFCmdBffr[0] = 0xE1; // Flush Tx FIFO.
				nRF24Strk.nRFVars.nRFInitEvnt   = CLR_IRQ;
				nRF_SetCmd(1);
			break;
			case CLR_IRQ:
				nRF24Strk.nRFVars.nRFCmdBffr[0] = WRT_REG_CMD | STATUS_REG_ADDRS;
				nRF24Strk.nRFVars.nRFCmdBffr[1] = 0x70; // Clear all IRQ.
				nRF24Strk.nRFVars.nRFInitEvnt   = DUMMPY_DATA;
				nRF_SetCmd(2);
			break;
			case DUMMPY_DATA:
				nRF24Strk.nRFFlags.nRFDlyStrt_F = True;
				nRF24Strk.nRFFlags.nRFInit_F    = True;
				nRF24Strk.nRFFlags.nRFTxCmplt_F = True;
				CE_LOW(); // Set nRF Transmit mode.
				HAL_Delay(5);
			break;
		}
	}
}

void nRF_SetCmd(uint8_t NumofByt2Snd)
{
	CSN_LOW();
	HAL_SPI_Transmit_IT(&hspi2, nRF24Strk.nRFVars.nRFCmdBffr, NumofByt2Snd);
}

void nRFTx_Data(void)
{
	if (nRF24Strk.nRFFlags.nRFTxCmplt_F)
	{
		nRF24Strk.nRFFlags.nRFTxCmplt_F = False;
		switch(nRF24Strk.nRFVars.nRFTrnsmtEvnt)
		{
			case TRNSMT_DATA:
				// Wait for your main loop interval timer and ensure SPI hardware is idle
				nRF24Strk.nRFVars.nRFTxBffr[0] = TRNSMT_CMD; // W_TX_PAYLOAD
				nRF24Strk.nRFVars.nRFTxBffr[1] = DateTmStrk.DateTmVars.HrsCntr;    // hrs
				nRF24Strk.nRFVars.nRFTxBffr[2] = DateTmStrk.DateTmVars.MinCntr;    // Min
				nRF24Strk.nRFVars.nRFTxBffr[3] = DateTmStrk.DateTmVars.SecCntr;    // Sec
				nRF24Strk.nRFVars.nRFTxBffr[4] = DateTmStrk.DateTmVars.DateVal;    // Date
				nRF24Strk.nRFVars.nRFTxBffr[5] = DateTmStrk.DateTmVars.MnthVal;    // Mon
				nRF24Strk.nRFVars.nRFTxBffr[6] = DateTmStrk.DateTmVars.YrsVal; 	   // year
				nRF24Strk.nRFVars.nRFTxBffr[7] = DateTmStrk.DateTmVars.DayVal;     // Week
				// Move to PULSE state instead of reading status immediately
				nRF24Strk.nRFVars.nRFTrnsmtEvnt = PULSE_CE;
				CSN_LOW();
				HAL_SPI_Transmit_IT(&hspi2, nRF24Strk.nRFVars.nRFTxBffr, 8);
			break;
			case PULSE_CE:
				CE_HIGH();
				SetDly(2500); // 2000 NOPs guarantees >15us on a 72MHz STM32
				CE_LOW();
				nRF24Strk.nRFFlags.nRFTxCmplt_F = True;
				nRF24Strk.nRFVars.nRFTrnsmtEvnt = READ_STATUS;
		break;
		case READ_STATUS:
				nRF24Strk.nRFVars.nRFTrnsmtEvnt = CLR_STATUS;
				nRF24Strk.nRFVars.statusCmd 	= STATUS_REG_ADDRS;
				nRF24Strk.nRFFlags.nRFTxCmplt_F = True;
				CSN_LOW();
				HAL_SPI_TransmitReceive_IT(&hspi2, &nRF24Strk.nRFVars.statusCmd, &nRF24Strk.nRFVars.StatusReg, 1);
		break;
		case CLR_STATUS:
			if (nRF24Strk.nRFFlags.nRFRxTxCmplt_F)
			{
				nRF24Strk.nRFFlags.nRFRxTxCmplt_F = False;
				if (nRF24Strk.nRFVars.StatusReg != 0xFF)
				{
					nRF24Strk.nRFVars.nRFFailerCntr++;
					if (nRF24Strk.nRFVars.StatusReg == 0x2E)
					{
						nRF24Strk.nRFVars.nRFFailerCntr = 0;
						nRF24Strk.nRFFlags.nRFBlnk_F    = True;
					}
					if (nRF24Strk.nRFVars.nRFFailerCntr > 9)
					{
						nRF24Strk.nRFVars.nRFFailerCntr = 0;
						nRF24Strk.nRFFlags.nRFInit_F    = False;
						nRF24Strk.nRFVars.nRFInitEvnt   = CONFIG_REG_ADDRS;
						nRF24Strk.nRFVars.nRFTrnsmtEvnt = TRNSMT_DATA;
					}
				}
				nRF24Strk.nRFVars.StatusReg     = 0;
				nRF24Strk.nRFVars.nRFCmdBffr[0] = WRT_REG_CMD | STATUS_REG_ADDRS;
				nRF24Strk.nRFVars.nRFCmdBffr[1] = 0x70; // Manually reset status flags
				nRF24Strk.nRFVars.nRFTrnsmtEvnt = FLSH_TXFIFO;
				nRF_SetCmd(2);
			}
			else
			{
				nRF24Strk.nRFVars.nRFTrnsmtEvnt = TRNSMT_DATA;
				nRF24Strk.nRFFlags.nRFTxCmplt_F = True;
			}
		break;
		case FLSH_TXFIFO:
			nRF24Strk.nRFVars.nRFCmdBffr[0]  = 0xE1; // Clean FIFO.
			nRF24Strk.nRFVars.nRFTrnsmtEvnt = TRNSMT_DATA;
			nRF24Strk.nRFFlags.nRFstrtTx    = False;
			nRF_SetCmd(1);
			SystmStrk.SystmFlags.StrtTrsnmt_F = True;
//			nRF24Strk.nRFFlags.nRFDlyStrt_F = True;
		break;
		/*case TRNSMT_CMPLT:
			nRF24Strk.nRFFlags.nRFTxCmplt_F = False;
		break;*/
		}
	}
}

void SetDly(uint16_t DlyCnt)
{
	uint16_t DlyCntr = 0;
	for(; DlyCntr < DlyCnt; DlyCntr++)
	{
		asm("NOP");
	}
}
