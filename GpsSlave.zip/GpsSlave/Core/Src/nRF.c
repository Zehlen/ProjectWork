/*
 * nRF.c
 *
 *  Created on: 01-Oct-2026
 *      Author: GURPREET
 */
#include "nRF.h"

__nRF24Strk nRF24Strk;

void Init_nRF24(void)
{
	if (nRF24Strk.nrFFlags.nRFTxCmplt_F)
	{
		nRF24Strk.nrFFlags.nRFTxCmplt_F = False;
		switch(nRF24Strk.nRFVars.nRFInitEvnt)
		{
			case CONFIG_REG_ADDRS:
				nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | CONFIG_REG_ADDRS;
				nRF24Strk.nRFVars.nRFBuffr[1] = 0x03;
				nRF24Strk.nRFVars.nRFInitEvnt = ENAA_REG_ADDRS;
				nRF_SetCmd(2);
			break;
			case ENAA_REG_ADDRS:
				CE_LOW();
				nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | ENAA_REG_ADDRS;
				nRF24Strk.nRFVars.nRFBuffr[1] = 0x00;
				nRF24Strk.nRFVars.nRFInitEvnt = EN_RXADDR_ADDRS;
				nRF_SetCmd(2);
			break;
			case EN_RXADDR_ADDRS:
				nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | EN_RXADDR_ADDRS;
				nRF24Strk.nRFVars.nRFBuffr[1] = 0x01;
				nRF24Strk.nRFVars.nRFInitEvnt = SETUP_AW_REG_ADDRS;
				nRF_SetCmd(2);
			break;
			case SETUP_AW_REG_ADDRS:
				nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | SETUP_AW_REG_ADDRS;
				nRF24Strk.nRFVars.nRFBuffr[1] = 0x03;
				nRF24Strk.nRFVars.nRFInitEvnt = RF_CH_REG_ADDRS;
				nRF_SetCmd(2);
			break;
			case RF_CH_REG_ADDRS:
				nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | RF_CH_REG_ADDRS;
				nRF24Strk.nRFVars.nRFBuffr[1] = 0x4c;
				nRF24Strk.nRFVars.nRFInitEvnt = RF_SETUP_REG_ADDRS;
				nRF_SetCmd(2);
			break;
			case RF_SETUP_REG_ADDRS:
				nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | RF_SETUP_REG_ADDRS;
				nRF24Strk.nRFVars.nRFBuffr[1] = 0x06; // 0 LNA gain ,RF power output 0dBm, Air data rate = 1Mbps.
				nRF24Strk.nRFVars.nRFInitEvnt = RX_ADDR_P0_REG_ADDRS;
				nRF_SetCmd(2);
			break;
			case RX_ADDR_P0_REG_ADDRS:
				nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | RX_ADDR_P0_REG_ADDRS;
				nRF24Strk.nRFVars.nRFBuffr[1] = 0xE7;
				nRF24Strk.nRFVars.nRFBuffr[2] = 0xE7;
				nRF24Strk.nRFVars.nRFBuffr[3] = 0xE7;
				nRF24Strk.nRFVars.nRFBuffr[4] = 0xE7;
				nRF24Strk.nRFVars.nRFBuffr[5] = 0xE7;
				nRF24Strk.nRFVars.nRFInitEvnt = RX_PW_P0_REG_ADDRS;
				nRF_SetCmd(6);
			break;
			case TX_ADDR_REG_ADDRS:
				nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | TX_ADDR_REG_ADDRS;
				nRF24Strk.nRFVars.nRFBuffr[1] = 0xE7;
				nRF24Strk.nRFVars.nRFBuffr[2] = 0xE7;
				nRF24Strk.nRFVars.nRFBuffr[3] = 0xE7;
				nRF24Strk.nRFVars.nRFBuffr[4] = 0xE7;
				nRF24Strk.nRFVars.nRFBuffr[5] = 0xE7;
				nRF24Strk.nRFVars.nRFInitEvnt = RX_PW_P0_REG_ADDRS;
				nRF_SetCmd(6);
			break;
			case RX_PW_P0_REG_ADDRS:
				nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | RX_PW_P0_REG_ADDRS;
				nRF24Strk.nRFVars.nRFBuffr[1] = 0x08;
				nRF24Strk.nRFVars.nRFInitEvnt = FLUSH_RX_FIFO;
				nRF_SetCmd(2);
			break;
            case FLUSH_RX_FIFO:
                nRF24Strk.nRFVars.nRFBuffr[0] = FLUSH_RX_FIFO; // Flush RX FIFO command
                nRF24Strk.nRFVars.nRFInitEvnt = FLUSH_TX_FIFO;
                nRF_SetCmd(1);
            break;
            case FLUSH_TX_FIFO:
                nRF24Strk.nRFVars.nRFBuffr[0] = FLUSH_TX_FIFO; // Flush RX FIFO command
                nRF24Strk.nRFVars.nRFInitEvnt = CLR_IRQ;
                nRF_SetCmd(1);
			break;
            case CLR_IRQ:
                nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | STATUS_REG_ADDRS;
                nRF24Strk.nRFVars.nRFBuffr[1] = 0x70; // Clear all interrupts
                nRF24Strk.nRFVars.nRFInitEvnt = FEATURE_REG_ADDRS;
                nRF_SetCmd(2);
            break;
            case FEATURE_REG_ADDRS:
            	 nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | FEATURE_REG_ADDRS;
            	 nRF24Strk.nRFVars.nRFBuffr[1] = 0x00; // Clear all interrupts
            	 nRF24Strk.nRFVars.nRFInitEvnt = START_LISTENING;
            	 nRF_SetCmd(2);
			break;
            case START_LISTENING:
                nRF24Strk.nrFFlags.nRFInit_F 	= True;
                nRF24Strk.nrFFlags.nRFDlyStrt_F = True;
                CE_HIGH(); // Keep CE High to listen constantly.
                HAL_Delay(5);
            break;
		}
	}
}

void nRF24_SetRxMode(void)
{
    nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | CONFIG_REG_ADDRS;
    nRF24Strk.nRFVars.nRFBuffr[1] = 0x0F; // CONFIG register: PWR_UP = 1, PRIM_RX = 1
    nRF_SetCmd(2);
}

void nRF24_SetTxMode(void)
{
    CE_LOW();
    nRF24Strk.nRFVars.nRFBuffr[0] = WRT_REG_CMD | CONFIG_REG_ADDRS;
    nRF24Strk.nRFVars.nRFBuffr[1] = 0x0E; // CONFIG register: PWR_UP = 1, PRIM_RX = 0
    nRF_SetCmd(2);
}

void nRF_SetCmd(uint8_t NumOfByt2Snd)
{
	CSN_LOW();
	HAL_SPI_Transmit_IT(&hspi2, nRF24Strk.nRFVars.nRFBuffr, NumOfByt2Snd);
}

void nRF_Rx_Data(uint8_t NumOfByt2Rcv)
{
	CSN_LOW();
	HAL_SPI_Receive_IT(&hspi2, nRF24Strk.nRFVars.nRFBuffr, NumOfByt2Rcv);
}

void nRFRx_Data(void)
{
    switch(nRF24Strk.nRFVars.nRFRecvEvnt)
    {
        case POLL_STATUS:
			nRF24Strk.nRFVars.nRFRecvEvnt     = CHECK_DATA;
			nRF24Strk.nRFVars.nRFStatusCmd    = STATUS_REG_ADDRS; // 0x07 Read Status
			nRF24Strk.nrFFlags.nRFTxCmplt_F   = False;
			nRF24Strk.nrFFlags.nRFRxTxCmplt_F = False;
			nRF24Strk.nrFFlags.nRFDlyStrt_F   = False;
//			DsplyStrk.DsplyFlags.GpsSgnlLed_F = True;
			CSN_LOW();
			HAL_SPI_TransmitReceive_IT(&hspi2, &nRF24Strk.nRFVars.nRFStatusCmd, &nRF24Strk.nRFVars.nRFStatusReg, 1);
        break;
        case CHECK_DATA:
            if (nRF24Strk.nrFFlags.nRFRxTxCmplt_F)
            {
                nRF24Strk.nrFFlags.nRFRxTxCmplt_F = False;
                // Bit 6 of STATUS is RX_DR (Data Ready RX FIFO interrupt)
				nRF24Strk.nRFVars.nRFRecvEvnt = POLL_STATUS;
				if (nRF24Strk.nRFVars.nRFStatusReg == 0x40)
				{
					nRF24Strk.nrFFlags.nRFTxCmplt_F     = True; // Flag manual release to transition immediately
//					DateTmStrk.DateTmFlags.WrtDateTm_F  = True;
					nRF24Strk.nRFVars.nRFFailerCntr     = 0;
					SystmStrk.SystmFlags.GpsSnglActv_F  = True;
					nRF24Strk.nRFVars.nRFRecvEvnt       = READ_PAYLOAD;
				}
				else
				{
					nRF24Strk.nRFVars.nRFFailerCntr++;
					SystmStrk.SystmFlags.GpsSnglActv_F  = False;
//					DsplyStrk.DsplyFlags.GpsSgnlLed_F   = False;
//					DateTmStrk.DateTmFlags.WrtDateTm_F  = False;
					nRF24Strk.nrFFlags.nRFDlyStrt_F     = True;
					SystmStrk.SystmFlags.WrtTmDlyStrt_F = False;
					nRF24Strk.nrFFlags.nRFRxStrt_F      = False;
				}
				if (nRF24Strk.nRFVars.nRFFailerCntr > 19)
				{
					nRF24Strk.nRFVars.nRFFailerCntr    = 0;
//					nRF24Strk.nrFFlags.nRFDlyStrt_F    = True;
				    nRF24Strk.nrFFlags.nRFInit_F       = False;
					nRF24Strk.nrFFlags.nRFTxCmplt_F    = True;
//					DsplyStrk.DsplyFlags.GpsSgnlLed_F = False;
//					SystmStrk.SystmFlags.GpsSnglActv_F = True;
					nRF24Strk.nRFVars.nRFInitEvnt      = CONFIG_REG_ADDRS;
					nRF24Strk.nRFVars.nRFRecvEvnt      = POLL_STATUS;
//					DsplyStrk.DsplyFlags.GpsSgnlLed_F = False;
				}
				/*if ((nRF24Strk.nRFVars.nRFStatusReg == 0xFF) || (nRF24Strk.nRFVars.nRFStatusReg == 0))
				{
					nRF24Strk.nRFVars.nRFInitCntr++;
					if (nRF24Strk.nRFVars.nRFInitCntr > 99)
					{
						nRF24Strk.nRFVars.nRFInitCntr      = 0;
						nRF24Strk.nrFFlags.nRfOpn_F        = True;
						nRF24Strk.nrFFlags.nRFInit_F       = True;
						DateTmStrk.DateTmFlags.WrtDateTm_F = False;
						nRF24Strk.nRFVars.nRFFailerCntr    = 2;
					}
				}*/
                nRF24Strk.nRFVars.nRFStatusReg = 0;
            }
            else
            {
            	nRF24Strk.nRFVars.nRFFailerCntr++;
            	if (nRF24Strk.nRFVars.nRFFailerCntr > 9)
				{
					nRF24Strk.nRFVars.nRFFailerCntr = 0;
					nRF24Strk.nrFFlags.nRFDlyStrt_F = True;
					nRF24Strk.nrFFlags.nRFRxStrt_F  = False;
					nRF24Strk.nRFVars.nRFRecvEvnt   = POLL_STATUS;
//					DsplyStrk.DsplyFlags.GpsSgnlLed_F   = False;
//					DateTmStrk.DateTmFlags.WrtDateTm_F  = False;
				}
            }
        break;
        case READ_PAYLOAD:
            if (nRF24Strk.nrFFlags.nRFTxCmplt_F)
            {
                nRF24Strk.nrFFlags.nRFTxCmplt_F = False;

                // Clear out tx buffer and insert R_RX_PAYLOAD command (0x61)
                nRF24Strk.nRFVars.nRFBuffr[0] = 0x61;
                nRF24Strk.nRFVars.nRFBuffr[1] = 0x00;
                nRF24Strk.nRFVars.nRFBuffr[2] = 0x00;
                nRF24Strk.nRFVars.nRFBuffr[3] = 0x00;
                nRF24Strk.nRFVars.nRFBuffr[4] = 0x00;
                nRF24Strk.nRFVars.nRFBuffr[5] = 0x00;
                nRF24Strk.nRFVars.nRFBuffr[6] = 0x00;
                nRF24Strk.nRFVars.nRFBuffr[7] = 0x00;
                CSN_LOW();
                nRF24Strk.nRFVars.nRFRecvEvnt = PROCESS_PAYLOAD;
                HAL_SPI_TransmitReceive_IT(&hspi2, nRF24Strk.nRFVars.nRFBuffr, nRF24Strk.nRFVars.nRFRxBuffr, 8);
            }
        break;
        case PROCESS_PAYLOAD:
            if (nRF24Strk.nrFFlags.nRFRxTxCmplt_F)
            {
                nRF24Strk.nrFFlags.nRFRxTxCmplt_F = False;
				SystmStrk.SystmVars.RcvdHrs     = nRF24Strk.nRFVars.nRFRxBuffr[1];
				SystmStrk.SystmVars.RcvdMin     = nRF24Strk.nRFVars.nRFRxBuffr[2];
				SystmStrk.SystmVars.RcvdSec     = nRF24Strk.nRFVars.nRFRxBuffr[3];
				SystmStrk.SystmVars.RcvdDate    = nRF24Strk.nRFVars.nRFRxBuffr[4];
				SystmStrk.SystmVars.RcvdMnth    = nRF24Strk.nRFVars.nRFRxBuffr[5];
				SystmStrk.SystmVars.RcvdYear    = nRF24Strk.nRFVars.nRFRxBuffr[6];
				SystmStrk.SystmVars.RcvdDay     = nRF24Strk.nRFVars.nRFRxBuffr[7];
				SetDateTime();
				nRF24Strk.nrFFlags.nRFTxCmplt_F = True;
				nRF24Strk.nRFVars.nRFRecvEvnt   = FLUSH_RX_FIFO;
//			    DateTmStrk.DateTmFlags.WrtDateTm_F  = True;
            }
        break;
        case FLUSH_RX_FIFO:
        	if (nRF24Strk.nrFFlags.nRFTxCmplt_F)
			{
				nRF24Strk.nrFFlags.nRFTxCmplt_F   = False;
				nRF24Strk.nRFVars.nRFBuffr[0]     = FLUSH_RX_FIFO;
				nRF24Strk.nRFVars.nRFRecvEvnt     = CLR_RX_FLAG;
				nRF_SetCmd(1);
//              nRF24Strk.nrFFlags.nRFDlyStrt_F = True;
			}
		break;
        case CLR_RX_FLAG:
            if (nRF24Strk.nrFFlags.nRFTxCmplt_F)
            {
                nRF24Strk.nrFFlags.nRFTxCmplt_F = False;
                nRF24Strk.nRFVars.nRFBuffr[0]   = WRT_REG_CMD | STATUS_REG_ADDRS;
                nRF24Strk.nRFVars.nRFBuffr[1]   = 0x40; // Write 1 to RX_DR to reset the flag
                nRF24Strk.nRFVars.nRFRecvEvnt   = DATETIME_SET;
                nRF_SetCmd(2);
            }
        break;
        case DATETIME_SET:
        	if (nRF24Strk.nrFFlags.nRFTxCmplt_F)
        	{
    			nRF24Strk.nrFFlags.nRFTxDlyStrt_F  = True;
        		nRF24Strk.nrFFlags.nRFTxCmplt_F    = False;
    			nRF24Strk.nrFFlags.nRFRxStrt_F     = False;
//				DsplyStrk.DsplyFlags.GpsSgnlLed_F = False;
    			SystmStrk.SystmFlags.GpsSnglActv_F = True;
    			nRF24Strk.nRFVars.nRFRecvEvnt      = POLL_STATUS;
			}
//			TmpData  = nRF24Strk.nRFVars.nRFRxBuffr[1] << 16;
//			TmpData |= nRF24Strk.nRFVars.nRFRxBuffr[2] << 8;
//			TmpData |= nRF24Strk.nRFVars.nRFRxBuffr[3];
//			if (nRF24Strk.nRFVars.nRFprvsData != TmpData)
//			{
//				nRF24Strk.nRFVars.nRFprvsData  = TmpData;
//				nRF24Strk.nRFVars.nRFprvsData  = nRF24Strk.nRFVars.nRFRxBuffr[1] << 16;
//				nRF24Strk.nRFVars.nRFprvsData |= nRF24Strk.nRFVars.nRFRxBuffr[2] << 8;
//				nRF24Strk.nRFVars.nRFprvsData |= nRF24Strk.nRFVars.nRFRxBuffr[3];
//			}
		break;
    }
    if (SystmStrk.SystmFlags.I2c_RxCmplt_F)
    {
    	SystmStrk.SystmFlags.I2c_RxCmplt_F = False;
	}
}

void nRFTx_Data(void)
{
	if (nRF24Strk.nRFVars.nRFRecvEvnt >= READ_PAYLOAD && nRF24Strk.nRFVars.nRFRecvEvnt <= DATETIME_SET)
	{
		nRF24Strk.nrFFlags.nRFRxStrt_F = True;
		nRF24Strk.nrFFlags.nRFTxStrt_F = False;
	}
	else
	{
		switch(nRF24Strk.nRFVars.nRFTrnsmtEvnt)
		{
			case NRF_TX_MODE:
				CE_LOW();
				nRF24Strk.nrFFlags.nRFTxCmplt_F   = False;
				nRF24Strk.nrFFlags.nRFRxTxCmplt_F = False;
				nRF24Strk.nRFVars.nRFBuffr[0]   = WRT_REG_CMD | CONFIG_REG_ADDRS;
				nRF24Strk.nRFVars.nRFBuffr[1]   = 0x02; // Enable Tx mode only.
				nRF24Strk.nRFVars.nRFTrnsmtEvnt = TRNSMT_DATA;
				nRF_SetCmd(2);
			break;
			case TRNSMT_DATA:
				  if (nRF24Strk.nrFFlags.nRFTxCmplt_F)
				  {
					  nRF24Strk.nrFFlags.nRFTxCmplt_F = False;
					  nRF24Strk.nRFVars.nRFBuffr[0]   = TX_CMD; // W_TX_PAYLOAD
					  nRF24Strk.nRFVars.nRFBuffr[1]   = DateTmStrk.DateTmVars.HrsCntr;   // hrs
					  nRF24Strk.nRFVars.nRFBuffr[2]   = DateTmStrk.DateTmVars.MinCntr;   // Min
					  nRF24Strk.nRFVars.nRFBuffr[3]   = DateTmStrk.DateTmVars.SecCntr;   // Sec
					  nRF24Strk.nRFVars.nRFBuffr[4]   = DateTmStrk.DateTmVars.DateVal;   // Date
					  nRF24Strk.nRFVars.nRFBuffr[5]   = DateTmStrk.DateTmVars.MnthVal;   // Mon
					  nRF24Strk.nRFVars.nRFBuffr[6]   = DateTmStrk.DateTmVars.YrsVal;    // year
					  nRF24Strk.nRFVars.nRFBuffr[7]   = DateTmStrk.DateTmVars.DayVal;    // Week
					  nRF24Strk.nRFVars.nRFTrnsmtEvnt = PULSE_CE;
					  nRF_SetCmd(8);
				  }
			break;
			case PULSE_CE:
				if (nRF24Strk.nrFFlags.nRFTxCmplt_F)
				{
					nRF24Strk.nrFFlags.nRFTxCmplt_F = False;
					CE_HIGH();
					nRF24Strk.nrFFlags.nRFPlusStrt_F = True;
//					SetDly(2500); // 2000 NOPs guarantees >15us on a 72MHz STM32
				}
				if (nRF24Strk.nrFFlags.nRFPlusTmOt_F)
				{
					nRF24Strk.nrFFlags.nRFPlusTmOt_F = False;
					CE_LOW();
					nRF24Strk.nRFVars.nRFTrnsmtEvnt = READ_STATUS;
				}
			break;
			case READ_STATUS:
					nRF24Strk.nRFVars.nRFTrnsmtEvnt = CLR_STATUS;
					nRF24Strk.nRFVars.nRFStatusCmd 	= STATUS_REG_ADDRS;
					CSN_LOW();
					HAL_SPI_TransmitReceive_IT(&hspi2, &nRF24Strk.nRFVars.nRFStatusCmd, &nRF24Strk.nRFVars.nRFStatusReg, 1);
			break;
			case CLR_STATUS:
				if (nRF24Strk.nrFFlags.nRFRxTxCmplt_F)
				{
					nRF24Strk.nrFFlags.nRFRxTxCmplt_F = False;
					nRF24Strk.nRFVars.nRFTrnsmtEvnt   = NRF_TX_MODE;
					nRF24Strk.nRFVars.nRFFailerCntr++;
					if (nRF24Strk.nRFVars.nRFStatusReg == 0x2E || nRF24Strk.nRFVars.nRFStatusReg == 0x60)
					{
						nRF24Strk.nRFVars.nRFFailerCntr = 0;
						nRF24Strk.nRFVars.nRFStatusReg  = 0;
						nRF24Strk.nrFFlags.nRFBlnk_F    = True;
						nRF24Strk.nRFVars.nRFBuffr[0]   = WRT_REG_CMD | STATUS_REG_ADDRS;
						nRF24Strk.nRFVars.nRFBuffr[1]   = 0x70; // Manually reset status flags
						nRF24Strk.nRFVars.nRFTrnsmtEvnt = FLSH_TXFIFO;
						nRF_SetCmd(2);
					}
					if (nRF24Strk.nRFVars.nRFFailerCntr > 4)
					{
						nRF24Strk.nRFVars.nRFFailerCntr   = 0;
						nRF24Strk.nrFFlags.nRFTxCmplt_F   = True;
						nRF24Strk.nrFFlags.nRFTxDlyStrt_F = True;
//						nRF24Strk.nrFFlags.nRFInit_F    = False;
//						nRF24Strk.nRFVars.nRFInitEvnt   = CONFIG_REG_ADDRS;
					}
				}
				else
				{
					nRF24Strk.nRFVars.nRFFailerCntr++;
					if (nRF24Strk.nRFVars.nRFFailerCntr > 19)
					{
						nRF24Strk.nRFVars.nRFFailerCntr = 0;
						nRF24Strk.nrFFlags.nRFTxCmplt_F = True;
						nRF24Strk.nrFFlags.nRFTxStrt_F  = False;
						nRF24Strk.nrFFlags.nRFInit_F    = False;
						nRF24Strk.nRFVars.nRFInitEvnt   = CONFIG_REG_ADDRS;
						nRF24Strk.nRFVars.nRFTrnsmtEvnt = NRF_TX_MODE;
					}
				}
			break;
			case FLSH_TXFIFO:
				if (nRF24Strk.nrFFlags.nRFTxCmplt_F)
				{
					nRF24Strk.nrFFlags.nRFTxCmplt_F = False;
					nRF24Strk.nRFVars.nRFBuffr[0]   = FLUSH_TX_FIFO; // Clean FIFO out to remain pristine
					nRF24Strk.nRFVars.nRFTrnsmtEvnt = NRF_RX_MODE;
					nRF_SetCmd(1);
				}
			break;
			case NRF_RX_MODE:
				if (nRF24Strk.nrFFlags.nRFTxCmplt_F)
				{
					nRF24Strk.nrFFlags.nRFTxCmplt_F = False;
					nRF24Strk.nRFVars.nRFBuffr[0]   = WRT_REG_CMD | CONFIG_REG_ADDRS;
					nRF24Strk.nRFVars.nRFBuffr[1]   = 0x03; // Enable Tx mode only.
					nRF24Strk.nRFVars.nRFTrnsmtEvnt = START_LISTENING;
					nRF_SetCmd(2);
				}
			break;
			case START_LISTENING:
				if (nRF24Strk.nrFFlags.nRFTxCmplt_F)
				{
					nRF24Strk.nrFFlags.nRFTxStrt_F  = False;
					nRF24Strk.nrFFlags.nRFTxCmplt_F = False;
					nRF24Strk.nrFFlags.nRFDlyStrt_F = True;
					CE_HIGH();
					nRF24Strk.nRFVars.nRFTrnsmtEvnt = NRF_TX_MODE;
				}
			break;
		}
	}
}

void SetDly(uint16_t DlyCnt)
{
	uint16_t DlyCntr = 0;
	for(; DlyCntr < DlyCnt; DlyCntr++)
	{
		asm("NOP");
	}
}
