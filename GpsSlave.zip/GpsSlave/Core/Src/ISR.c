/*
 * ISR.c
 *
 *  Created on: 03-Sept-2026
 *      Author: Malcolm.X
 */

#include "ISR.h"

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if (htim->Instance == TIM3)
	{
		DateTmStrk.DateTmVars.MillSecCntr++;
/*--------------------------- Second Delay ------------------------ */
		if (DateTmStrk.DateTmVars.MillSecCntr > SECDLY_CNT)
		{
			DateTmStrk.DateTmVars.MillSecCntr = 0;
			if ((SystmStrk.SystmFlags.IncKey_F && SystmStrk.SystmFlags.ShftKey_F))
			{
				SystmStrk.SystmVars.ClckSttngCntr++;
				if (SystmStrk.SystmVars.ClckSttngCntr > STTNGDLY_CNT)
				{
					if ((GPIOB->IDR & SHFT_PB1_Pin) == (uint32_t)GPIO_PIN_RESET && ((GPIOB->IDR & INC_PB4_Pin) == (uint32_t)GPIO_PIN_RESET))
					{
						SystmStrk.SystmVars.ClckSttngCntr  = 0;
						SystmStrk.SystmFlags.ShftKey_F 	   = False;
						SystmStrk.SystmFlags.IncKey_F  	   = False;
						SystmStrk.SystmFlags.ClckSttng_F   = True;
					}
				}
				if (SystmStrk.SystmVars.ClckSttngCntr < STTNGDLY_CNT)
				{
					if (((GPIOB->IDR & SHFT_PB1_Pin) != (uint32_t)GPIO_PIN_RESET) || (((GPIOB->IDR & INC_PB4_Pin) != (uint32_t)GPIO_PIN_RESET)))
					{
						SystmStrk.SystmFlags.ShftKey_F 	  = False;
						SystmStrk.SystmFlags.IncKey_F  	  = False;
						SystmStrk.SystmVars.ClckSttngCntr = 0;
					}
				}
			}
			if (DsplyStrk.DsplyFlags.DsplyDlyStrt_F)
			{
				DsplyStrk.DsplyVars.DsplyDlyCntr++;
				if (DsplyStrk.DsplyVars.DsplyDlyCntr > DSPLYDLY_CNT)
				{
					DsplyStrk.DsplyVars.DsplyDlyCntr 	 = 0;
					DsplyStrk.DsplyFlags.DsplyDlyTmOut_F = True;
					DsplyStrk.DsplyFlags.DsplyDlyStrt_F  = False;
				}
			}
			if (UrtStrk.UrtFlags.MdbsTxDlyStrt_F)
			{
				UrtStrk.UrtVars.MdbsTxDlyCntr++;
				if (UrtStrk.UrtVars.MdbsTxDlyCntr > 4)
				{
					UrtStrk.UrtVars.MdbsTxDlyCntr    = 0;
					UrtStrk.UrtFlags.MdbsTxTmOut_F   = True;
					UrtStrk.UrtFlags.MdbsTxDlyStrt_F = False;
				}
			}
			if (nRF24Strk.nrFFlags.nRFTxDlyStrt_F)
			{
				nRF24Strk.nRFVars.nRFTxDlyCntr++;
				if (nRF24Strk.nRFVars.nRFTxDlyCntr > 9)
				{
					nRF24Strk.nRFVars.nRFTxDlyCntr    = 0;
					nRF24Strk.nrFFlags.nRFTxStrt_F    = True;
					nRF24Strk.nrFFlags.nRFTxDlyStrt_F = False;
				}
			}
		}
/*--------------------------- Second Delay end ---------------------*/

/*--------------------------- nRF Rx delay --------------------------*/
		if (nRF24Strk.nrFFlags.nRFDlyStrt_F)
		{
			nRF24Strk.nRFVars.nRFDlyCntr++;
			if (nRF24Strk.nRFVars.nRFDlyCntr > 199)
			{
				nRF24Strk.nRFVars.nRFDlyCntr    = 0;
				nRF24Strk.nrFFlags.nRFRxStrt_F  = True;
				nRF24Strk.nrFFlags.nRFDlyStrt_F = False;
			}
		}
		if (nRF24Strk.nrFFlags.nRFPlusStrt_F)
		{
			nRF24Strk.nRFVars.nRFPlusCntr++;
			nRF24Strk.nrFFlags.nRFTxCmplt_F = True;
			if (nRF24Strk.nRFVars.nRFPlusCntr > 4)
			{
				nRF24Strk.nRFVars.nRFPlusCntr    = 0;
				nRF24Strk.nrFFlags.nRFPlusStrt_F = False;
				nRF24Strk.nrFFlags.nRFPlusTmOt_F = True;
			}
		}
/*--------------------------- nRF Rx delay end ----------------------*/

/*--------------------------- Modbus Delay -------------------------*/
		if (UrtStrk.UrtFlags.MdbsDlyStrt_F)
		{
			UrtStrk.UrtVars.MdbRxDlyCntr++;
			if (UrtStrk.UrtVars.MdbRxDlyCntr > 199)
			{
				UrtStrk.UrtVars.MdbRxDlyCntr 	= 0;
				UrtStrk.UrtFlags.MdbsDlyTmOut_F = True;
			}
		}
/*--------------------------- Modbus Delay end ---------------------*/

/*--------------------------- Clock Delay --------------------------*/
		if (SystmStrk.SystmFlags.ClckDlyStrt_F)
		{
			SystmStrk.SystmVars.ClckDlyCntr++;
			if (SystmStrk.SystmVars.ClckDlyCntr > CLCKDLY_CNT)
			{
				SystmStrk.SystmVars.ClckDlyCntr 	= 0;
				SystmStrk.SystmFlags.ClckDlyTmOut_F = True;
				SystmStrk.SystmFlags.ClckDlyStrt_F  = False;
			}
		}
/*--------------------------- Clock Delay end ----------------------*/

/*		if (UrtStrk.UrtFlags.GpsDlyStrt_F)
		{
			UrtStrk.UrtVars.GpsDlyCntr++;
			if (UrtStrk.UrtVars.GpsDlyCntr > UrtStrk.UrtVars.GpsDlyCnt)
			{
				UrtStrk.UrtVars.GpsDlyCntr     = 0;
				UrtStrk.UrtFlags.GpsDlyTmOut_F = True;
				UrtStrk.UrtFlags.GpsRxCmplt_F  = True;
			}
		}*/

/*--------------------------- Debounce Delay ------------------------*/
		if (SystmStrk.SystmFlags.KeyPrss_F)
		{
			SystmStrk.SystmVars.KeyDlyCntr++;
			if (SystmStrk.SystmVars.KeyDlyCntr > DBUNCDLY_CNT)
			{
				SystmStrk.SystmVars.KeyDlyCntr = 0;
				SystmStrk.SystmFlags.KeyPrss_F = False;
				if (SystmStrk.SystmVars.KeyVals == ENTR_PB0_Pin)
				{
					if ((GPIOB->IDR & SystmStrk.SystmVars.KeyVals) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.EntrKey_F = True;
					}
				}
				if (SystmStrk.SystmVars.KeyVals == SHFT_PB1_Pin)
				{
					if ((GPIOB->IDR & SystmStrk.SystmVars.KeyVals) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.ShftKey_F = True;
					}
					if ((GPIOB->IDR & INC_PB4_Pin) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.IncKey_F = True;
					}
				}
				if (SystmStrk.SystmVars.KeyVals == INC_PB4_Pin)
				{
					if ((GPIOB->IDR & SystmStrk.SystmVars.KeyVals) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.IncKey_F = True;
					}
					if ((GPIOB->IDR & SHFT_PB1_Pin) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.ShftKey_F = True;
					}
				}
				if (SystmStrk.SystmVars.KeyVals == EXT_PB3_Pin)
				{
					if ((GPIOB->IDR & SystmStrk.SystmVars.KeyVals) == (uint32_t)GPIO_PIN_RESET)
					{
						SystmStrk.SystmFlags.ExtKey_F = True;
					}
				}
			}
		}
/*--------------------------- Debounce Delay end --------------------*/

/*--------------------------- Display blink delay -------------------*/
		if (DsplyStrk.DsplyFlags.DsplBlnkStrt_F)
		{
			DsplyStrk.DsplyVars.DsplyBlnkCntr++;
			if (DsplyStrk.DsplyVars.DsplyBlnkCntr > DSPLYBLNK_CNT)
			{
				DsplyStrk.DsplyVars.DsplyBlnkCntr 	  = 0;
				DsplyStrk.DsplyFlags.DSplyBlnkTmOut_F = ~DsplyStrk.DsplyFlags.DSplyBlnkTmOut_F;
			}
		}
/*--------------------------- Display blink delay end ---------------*/

/*--------------------------- Clock heart delay ---------------------*/
		if (SystmStrk.SystmFlags.ClckHrtBlnkStrt_F)
		{
			DsplyStrk.DsplyFlags.ClckHrt_F = False;
			if (DateTmStrk.DateTmVars.MillSecCntr > CLCKHRTDLY_CNT)
			{
				DsplyStrk.DsplyFlags.ClckHrt_F = True;
			}
		}
/*--------------------------- Clock heart delay end -----------------*/

		if (SystmStrk.SystmFlags.GpsSnglActv_F)
		{
			SystmStrk.SystmVars.GpsSnglCntr++;
			if (SystmStrk.SystmVars.GpsSnglCntr > GPSSGNLLED_CNT)
			{
				SystmStrk.SystmVars.GpsSnglCntr    = 0;
				SystmStrk.SystmFlags.GpsSnglActv_F = False;
				DsplyStrk.DsplyFlags.GpsSgnlLed_F  = ~ DsplyStrk.DsplyFlags.GpsSgnlLed_F;
			}
		}
		else
		{
			DsplyStrk.DsplyFlags.GpsSgnlLed_F = False;
		}

/*--------------------------- Watch delay --------------------------*/
		if (SystmStrk.SystmFlags.WtchCntrStrt_F)
		{
			SystmStrk.SystmVars.WtchCntr++;
			if (!DsplyStrk.DsplyFlags.DsplyWrtCmplt_F)
			{
				if (SystmStrk.SystmVars.WtchCntr > 999)
				{
					DsplyStrk.DsplyFlags.DsplyWrtCmplt_F = True;
					SystmStrk.SystmFlags.I2c_RxCmplt_F   = True;
				}
			}
			if (SystmStrk.SystmVars.WtchCntr > 999)
			{
				SystmStrk.SystmVars.WtchCntr = 0;
			}
		}
/*--------------------------- Watch delay end ----------------------*/

		DsplyStrk.DsplyFlags.DsplySwTmOt_F = True;
	}
}

void HAL_I2C_MemTxCpltCallback(I2C_HandleTypeDef *hi2c)
{
//	DsplyStrk.DsplyFlags.DsplyWrtCmplt_F = True;
	SystmStrk.SystmFlags.I2c_TxCmplt_F   = True;
}

void HAL_I2C_MemRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
//	DsplyStrk.DsplyFlags.DsplyWrtCmplt_F = True;
	SystmStrk.SystmFlags.I2c_RxCmplt_F   = True;
}

void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c)
{
	asm("NOP");
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if (huart->Instance == USART1)
	{
		UrtStrk.UrtFlags.MdbsRxCmplt_F = True;
	}
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	if (huart->Instance == USART1)
	{
		UrtStrk.UrtFlags.MdbsTxCmplt_F   = True;
		UrtStrk.UrtFlags.MdbsTxDlyStrt_F = True;
		nRF24Strk.nrFFlags.nRFBlnk_F     = True;
	}
}

void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi)
{
	CSN_HIGH();
	nRF24Strk.nrFFlags.nRFTxCmplt_F = True;
}

void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi)
{
	asm("NOP");
}

void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
	CSN_HIGH();
	nRF24Strk.nrFFlags.nRFRxTxCmplt_F = True;
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	SystmStrk.SystmFlags.KeyPrss_F = True;
	SystmStrk.SystmVars.KeyVals    = (uint8_t)GPIO_Pin;
}
