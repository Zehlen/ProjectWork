/*
 * Uart.c
 *
 *  Created on: 05-Sept-2026
 *      Author: Malcolm.X
 */
#include "Uart.h"

// $GPRMC,095559.084,V,,,,,0.00,0.00,150926,,,N,V*37
__UartStrk UrtStrk;

void ChckRqust (void)
{
	SystmStrk.SystmFlags.WrtTmDlyStrt_F = False;
	UrtStrk.UrtFlags.MdbsDataStrt_F     = False;
	if (UrtStrk.UrtVars.UrtBffr[0] <= SystmStrk.SystmVars.SlvId)
	{
        UrtStrk.UrtVars.RegStrtAddrs = UrtStrk.UrtVars.UrtBffr[3];
        if(UrtStrk.UrtVars.RegStrtAddrs >=0 && UrtStrk.UrtVars.RegStrtAddrs <= 8)
        {
            UrtStrk.UrtVars.RegCnt = UrtStrk.UrtVars.UrtBffr[5];
            if(UrtStrk.UrtVars.RegCnt <= 10)
            {
				CrtRspons();
            }
        }
	}
}

void CrtRspons(void)
{
    if(UrtStrk.UrtVars.UrtBffr[1] == WRT_MLT_REG)
    {
/*-------------------------------Set 12 mode Hrs-------------------------------------*/
    	SystmStrk.SystmFlags.WrtTmDlyStrt_F = True;
		DsplyStrk.DsplyFlags.GpsSgnlLed_F   = True;
		UrtStrk.UrtFlags.MdbsDataStrt_F     = True;
    	if((UrtStrk.UrtVars.UrtBffr[22] % 100) == __12HRSMD__)
        {
            DateTmStrk.DateTmFlags.Hrs24_12_F = Sclt12Hrs;
            if(UrtStrk.UrtVars.UrtBffr[8] >= 1 && UrtStrk.UrtVars.UrtBffr[8] <= 12)
            {
            	SystmStrk.SystmVars.RcvdHrs = UrtStrk.UrtVars.UrtBffr[8];
            }
        }
        if((UrtStrk.UrtVars.UrtBffr[22] / 100) == ScltPm)
        {
            DateTmStrk.DateTmFlags.AmPM_F = ScltPm;
        }
        if((UrtStrk.UrtVars.UrtBffr[22] / 100) == ScltAm)
        {
            DateTmStrk.DateTmFlags.AmPM_F = ScltAm;
        }
/*-------------------------------Set 12 mode Hrs end-----------------------------------*/

/*-------------------------------Set 24 mode Hrs---------------------------------------*/
        if((UrtStrk.UrtVars.UrtBffr[22] % 100) == __24HRSMD__)
        {
            DateTmStrk.DateTmFlags.Hrs24_12_F = Sclt24Hrs;
            if(UrtStrk.UrtVars.UrtBffr[8] >= 0 && UrtStrk.UrtVars.UrtBffr[8] <= 23)
            {
            	SystmStrk.SystmVars.RcvdHrs = UrtStrk.UrtVars.UrtBffr[8];
            }
        }
/*-------------------------------Set 24 mode Hrs end-----------------------------------*/

/*------------------------------------Set minute---------------------------------------*/
        if(UrtStrk.UrtVars.UrtBffr[10] != 0)
        {
        	SystmStrk.SystmVars.RcvdMin = UrtStrk.UrtVars.UrtBffr[10];
        }
/*-----------------------------------Set minute end------------------------------------*/

/*-------------------------------------Set second--------------------------------------*/
        if(UrtStrk.UrtVars.UrtBffr[12] != 0)
        {
        	SystmStrk.SystmVars.RcvdSec = UrtStrk.UrtVars.UrtBffr[12];
        }
/*-------------------------------------Set second end-----------------------------------*/
        if(UrtStrk.UrtVars.UrtBffr[14] >=1 && UrtStrk.UrtVars.UrtBffr[14] <= 31)
        {
        	SystmStrk.SystmVars.RcvdDate = UrtStrk.UrtVars.UrtBffr[14];
        }
/*-------------------------------------Set Minute--------------------------------------*/
        if(UrtStrk.UrtVars.UrtBffr[16] >=1 && UrtStrk.UrtVars.UrtBffr[16] <= 12)
        {
        	SystmStrk.SystmVars.RcvdMnth = UrtStrk.UrtVars.UrtBffr[16];
        }
/*------------------------------------Set Minute end-----------------------------------*/

/*--------------------------------------Set Year---------------------------------------*/
        if(UrtStrk.UrtVars.UrtBffr[17] !=0 && UrtStrk.UrtVars.UrtBffr[18] != 0)
        {
        	SystmStrk.SystmVars.RcvdYear  = UrtStrk.UrtVars.UrtBffr[17] * 100;
        	SystmStrk.SystmVars.RcvdYear += UrtStrk.UrtVars.UrtBffr[18];
        	SystmStrk.SystmVars.RcvdYear %= 100;
        }
/*-------------------------------------Set Year end------------------------------------*/

/*----------------------------------------Set Day--------------------------------------*/
        if(UrtStrk.UrtVars.UrtBffr[20] >=1 && UrtStrk.UrtVars.UrtBffr[20] <= 7)
        {
        	SystmStrk.SystmVars.RcvdDay = UrtStrk.UrtVars.UrtBffr[20];
        }
/*---------------------------------------Set Day end-----------------------------------*/
//        CRCVal  = Calculate_CRC(UrtStrk.UrtVars.UrtBffr, 6);
//        UrtStrk.UrtVars.UrtBffr[6] = (uint8_t)(CRCVal  & 0xFF);
//        UrtStrk.UrtVars.UrtBffr[7] = (uint8_t)((CRCVal >> 0x08) & 0xFF);
//        HAL_UART_Transmit_DMA(&huart1, UrtStrk.UrtVars.UrtBffr, 8);

        SetDateTime();
    }
}

uint16_t Calculate_CRC(const uint8_t *pBuffer, uint16_t Length)
{
	uint16_t crc = 0xFFFF; // Modbus initial value
	uint16_t BffrCntr = 0;
    for (; BffrCntr < Length; BffrCntr++)
    {
        crc ^= pBuffer[BffrCntr]; // XOR byte into least sig. byte of crc
        for (uint8_t bit = 0; bit < 8; bit++)
        {
            if (crc & 0x0001)
            { // If the LSB is set
                crc >>= 1;
                crc ^= 0xA001;  // Modbus bit-reversed polynomial
            }
            else
            {
                crc >>= 1;
            }
        }
    }
    return crc;
}

/*void ParseGpsDateTime(void)
{
	uint8_t BffrCntr = 0, CmaCntr = 0, RMCFnd_F = 0;
	UrtStrk.UrtFlags.GpsDlyTmOut_F = False;
	for(; BffrCntr < URT_BFFR_LEN; BffrCntr++)
	{
		if ((UrtStrk.UrtVars.GpsBffr[BffrCntr] == 'R') && (UrtStrk.UrtVars.GpsBffr[BffrCntr+1] == 'M') && (UrtStrk.UrtVars.GpsBffr[BffrCntr+2] == 'C'))
		{
			UrtStrk.UrtFlags.GpsDlyTmOut_F = False;
			UrtStrk.UrtFlags.GpsDlyStrt_F  = True;
			if (UrtStrk.UrtVars.GpsBffr[BffrCntr+15] == 'A')
			{
				SystmStrk.SystmFlags.GpsSnglActv_F = True;
				RMCFnd_F						   = True;
				UrtStrk.UrtVars.UTcHrs  	   = (UrtStrk.UrtVars.GpsBffr[BffrCntr+4] & 0x0F) * 10;
				UrtStrk.UrtVars.UTcHrs 		  += (UrtStrk.UrtVars.GpsBffr[BffrCntr+5] & 0x0F);
				UrtStrk.UrtVars.UtcMin  	   = (UrtStrk.UrtVars.GpsBffr[BffrCntr+6] & 0x0F) * 10;
				UrtStrk.UrtVars.UtcMin        += (UrtStrk.UrtVars.GpsBffr[BffrCntr+7] & 0x0F);
				DateTmStrk.DateTmVars.SecCntr  = (UrtStrk.UrtVars.GpsBffr[BffrCntr+8] & 0x0F) * 10;
				DateTmStrk.DateTmVars.SecCntr += (UrtStrk.UrtVars.GpsBffr[BffrCntr+9] & 0x0F);
			}
			else
			{
				SystmStrk.SystmFlags.GpsSnglActv_F = False;
				break;
			}
		}
		if (RMCFnd_F)
		{
			if (UrtStrk.UrtVars.GpsBffr[BffrCntr] == ',')
			{
				CmaCntr++;
			}
			if (CmaCntr >= 10)
			{
				if (SystmStrk.SystmFlags.GpsSnglActv_F)
				{
					DateTmStrk.DateTmVars.YrsVal   = (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F);
					DateTmStrk.DateTmVars.YrsVal  += (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F)*10;
					DateTmStrk.DateTmVars.MnthVal  = (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F);
					DateTmStrk.DateTmVars.MnthVal += (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F)*10;
					DateTmStrk.DateTmVars.DateVal  = (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F);
					DateTmStrk.DateTmVars.DateVal += (UrtStrk.UrtVars.GpsBffr[--BffrCntr] & 0x0F)*10;
					if (DateTmStrk.DateTmVars.YrsVal != 26)
					{
						asm("NOP");
					}
					AddUtcOffst_ToLclTim();
					SetDateTime();
					UrtStrk.UrtVars.GpsDlyCnt = 999;
				}
				break;
			}
		}
	}
}*/

void TrnsmtDateTime(void)
{
	uint32_t UrtState = 0;
	HAL_GPIO_WritePin(GPIOA, URT_DR_PA11_Pin, GPIO_PIN_SET);
    //uint8_t  Dffrnc = 0, FrstTrm = 0, EndAddr = 0, StrtAddrs = 0, NumOfByts = 0, BffrCntr = 0;
	uint8_t BffrCntr = 0;
	uint16_t CRCVal  = 0;
	if ((SystmStrk.SystmVars.SlvId + 1) < 99)
	{
		UrtStrk.UrtVars.UrtBffr[BffrCntr++] = (SystmStrk.SystmVars.SlvId + 1);// Slave Id.
	}
	else
	{
		UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 1;// Slave Id.
	}
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x10; // Function code Reading holding register.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00; // Address Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00; // Address Lw Byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00; // Quantity Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x08; // Quantity Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x10; // Data byte count.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00; // Hrs Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.HrsCntr; // Hrs Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;						     // Min Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.MinCntr; // Min Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;							 // Sec Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.SecCntr; // Sec Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;							 // Date Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.DateVal; // Date Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;							 // Month Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.MnthVal; // Month Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x14;							 // Year Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.YrsVal;  // Year Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;						     // Day Hi byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = DateTmStrk.DateTmVars.DayVal;  // Day Lw byte.
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 0x00;							 // Clock mode.
	if (DateTmStrk.DateTmFlags.Hrs24_12_F == Sclt12Hrs)
	{
		if (DateTmStrk.DateTmFlags.AmPM_F == ScltPm)
		{
			UrtStrk.UrtVars.UrtBffr[BffrCntr++] =112;
		}
		else
		{
			UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 12;
		}
	}
	else
	{
		UrtStrk.UrtVars.UrtBffr[BffrCntr++] = 24;
	}

	CRCVal = Calculate_CRC(UrtStrk.UrtVars.UrtBffr, BffrCntr);
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = (uint8_t)(CRCVal  & 0xFF);
	UrtStrk.UrtVars.UrtBffr[BffrCntr++] = (uint8_t)((CRCVal >> 0x08) & 0xFF);
	UrtState = HAL_UART_GetState(&huart1);\
	if ((UrtState != HAL_UART_STATE_BUSY_TX) && (UrtState != HAL_UART_STATE_BUSY_RX))
	{
		HAL_UART_Transmit_DMA(&huart1, UrtStrk.UrtVars.UrtBffr, BffrCntr);
	}
}
