/*
 * Uart.h
 *
 *  Created on: 05-Sept-2026
 *      Author: Malcolm.X
 */

#ifndef INC_UART_H_
#define INC_UART_H_

#include "main.h"

#define WRT_MLT_REG    ((uint8_t)0x10)
#define MDBS_SLV_ADDR  ((uint8_t)0x01)
#define URT_BFFR_LEN   ((uint8_t)0x4A)
#define GPSACTV		   'A'

typedef struct
{
	volatile uint8_t NumOfByts2Snd;
	volatile uint8_t RegCnt;
	volatile uint8_t RegStrtAddrs;
//	volatile uint8_t UTcHrs;
//	volatile uint8_t UtcMin;
//	volatile uint8_t UtcSec;
	volatile uint8_t MdbRxDlyCntr;
	volatile uint8_t MdbsTxDlyCntr;

//	volatile uint16_t GpsDlyCntr;
//	volatile uint16_t GpsDlyCnt;
//	volatile int16_t UtcOffst;
			 uint8_t UrtBffr[26];
//			 uint8_t GpsBffr[100];
} __UartVars;

typedef struct
{
//	volatile unsigned GpsDlyStrt_F		:1;
//	volatile unsigned GpsDlyTmOut_F     :1;
//	volatile unsigned GpsRxCmplt_F		:1;
	volatile unsigned MdbsDataStrt_F    :1;
//	volatile unsigned GpsTxCmplt_F		:1;
	volatile unsigned MdbsRxCmplt_F     :1;
	volatile unsigned MdbsDlyStrt_F		:1;
	volatile unsigned MdbsDlyTmOut_F    :1;
//	volatile unsigned MdbsOpn_F			:1;
	volatile unsigned MdbsTxDlyStrt_F   :1;
	volatile unsigned MdbsTxStrt_F      :1;
	volatile unsigned MdbsTxCmplt_F     :1;
	volatile unsigned MdbsTxTmOut_F     :1;
} __UartFlags;

typedef struct
{
	__UartVars  UrtVars;
	__UartFlags UrtFlags;
} __UartStrk;

extern __UartStrk UrtStrk;

void CrtRspons 		   (void);
void ChckRqust 		   (void);
void TrnsmtDateTime	   (void);
//void ParseGpsDateTime  (void);

uint16_t Calculate_CRC (const uint8_t *pBuffer, uint16_t Length);

#endif /* INC_UART_H_ */
