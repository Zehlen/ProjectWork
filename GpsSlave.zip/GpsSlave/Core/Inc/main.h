/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"
#include "ISR.h"
#include "Clck.h"
#include "DS323.h"
#include "Uart.h"
#include "SystmStrk.h"
#include "nRF.h"

extern I2C_HandleTypeDef hi2c1;
extern SPI_HandleTypeDef hspi2;
extern TIM_HandleTypeDef htim3;
//extern TIM_HandleTypeDef htim4;
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart3;
extern DMA_HandleTypeDef  hdma_usart1_rx;
extern DMA_HandleTypeDef  hdma_usart1_tx;
extern DMA_HandleTypeDef  hdma_usart3_rx;
extern DMA_HandleTypeDef  hdma_usart3_tx;
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define DS_PC13_Pin GPIO_PIN_13
#define DS_PC13_GPIO_Port GPIOC
#define STCP_PC14_Pin GPIO_PIN_14
#define STCP_PC14_GPIO_Port GPIOC
#define SHCP_PC15_Pin GPIO_PIN_15
#define SHCP_PC15_GPIO_Port GPIOC

#define SEG_A_PA0_Pin GPIO_PIN_0
#define SEG_A_PA0_GPIO_Port GPIOA
#define SEG_B_PA1_Pin GPIO_PIN_1
#define SEG_B_PA1_GPIO_Port GPIOA
#define SEG_C_PA2_Pin GPIO_PIN_2
#define SEG_C_PA2_GPIO_Port GPIOA
#define SEG_D_PA3_Pin GPIO_PIN_3
#define SEG_D_PA3_GPIO_Port GPIOA
#define SEG_E_PA4_Pin GPIO_PIN_4
#define SEG_E_PA4_GPIO_Port GPIOA
#define SEG_F_PA5_Pin GPIO_PIN_5
#define SEG_F_PA5_GPIO_Port GPIOA
#define SEG_G_PA6_Pin GPIO_PIN_6
#define SEG_G_PA6_GPIO_Port GPIOA
#define SEG_H_PA7_Pin GPIO_PIN_7
#define SEG_H_PA7_GPIO_Port GPIOA

#define ENTR_PB0_Pin GPIO_PIN_0
#define ENTR_PB0_GPIO_Port GPIOB
#define ENTR_PB0_EXTI_IRQn EXTI0_IRQn
#define SHFT_PB1_Pin GPIO_PIN_1
#define SHFT_PB1_GPIO_Port GPIOB
#define SHFT_PB1_EXTI_IRQn EXTI1_IRQn
#define INC_PB4_Pin GPIO_PIN_4
#define INC_PB4_GPIO_Port GPIOB
#define INC_PB4_EXT4_IRQn EXTI4_IRQn
#define EXT_PB3_Pin GPIO_PIN_3
#define EXT_PB3_GPIO_Port GPIOB
#define EXT_PB3_EXTI_IRQn EXTI3_IRQn

#define UART3_TX_PB10_Pin GPIO_PIN_10
#define UART3_TX_PB10_GPIO_Port GPIOB
#define UART3_RX_PB11_Pin GPIO_PIN_11
#define UART3_RX_PB11_GPIO_Port GPIOB

#define CE_RXTX_PB12_Pin GPIO_PIN_12
#define CE_RXTX_PB12_GPIO_Port GPIOB
#define SPI2_SCK_PB13_Pin GPIO_PIN_13
#define SPI2_SCK_PB13_GPIO_Port GPIOB
#define SPI2_MISO_PB14_Pin GPIO_PIN_14
#define SPI2_MISO_PB14_GPIO_Port GPIOB
#define SPI2_MOSI_PB15_Pin GPIO_PIN_15
#define SPI2_MOSI_PB15_GPIO_Port GPIOB
#define CSN_PA8_Pin GPIO_PIN_8
#define CSN_PA8_GPIO_Port GPIOA

#define UART1_TX_PA9_Pin GPIO_PIN_9
#define UART1_TX_PA9_GPIO_Port GPIOA
#define UART1_RX_PA10_Pin GPIO_PIN_10
#define UART1_RX_PA10_GPIO_Port GPIOA
#define URT_DR_PA11_Pin  GPIO_PIN_11
#define URT_DR_PA11_GPIO_Port  GPIOA

#define CLCK_PM_PA12_Pin GPIO_PIN_12
#define CLCK_PM_PA12_GPIO_Port GPIOA
#define CLCK_AM_PA15_Pin GPIO_PIN_15
#define CLCK_AM_PA15_GPIO_Port GPIOA

#define I2C1_SCL_PB6_Pin GPIO_PIN_6
#define I2C1_SCL_PB6_GPIO_Port GPIOB
#define I2C1_SDA_PB7_Pin GPIO_PIN_7
#define I2C1_SDA_PB7_GPIO_Port GPIOB

#define CLCK_HRT_PB9_Pin GPIO_PIN_9
#define CLCK_HRT_PB9_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
