/*
 * nRF.h
 *
 *  Created on: 01-Oct-2026
 *      Author: GURPREET
 */

#ifndef INC_NRF_H_
#define INC_NRF_H_

#include "main.h"

typedef struct
{
	volatile uint8_t  nRFInitEvnt;
	volatile uint8_t  nRFRecvEvnt;
	volatile uint8_t  nRFTrnsmtEvnt;
	volatile uint8_t  nRFFailerCntr;
	volatile uint8_t  nRFTxDlyCntr;
	volatile uint8_t  nRFDlyCntr;
	volatile uint8_t  nRFPlusCntr;
			 uint8_t  nRFStatusReg;
			 uint8_t  nRFStatusCmd;
			 uint8_t  nRFBuffr[9];
			 uint8_t  nRFRxBuffr[9];
} __nRFVars;

typedef struct
{
	volatile unsigned nRFInit_F       :1;
	volatile unsigned nRFTxCmplt_F    :1;
	volatile unsigned nRFRxCmplt_F    :1;
	volatile unsigned nRFRxTxCmplt_F  :1;
	volatile unsigned nRFDlyStrt_F    :1;
	volatile unsigned nRFRxStrt_F     :1;
	volatile unsigned nRFTxDlyStrt_F  :1;
	volatile unsigned nRFTxStrt_F	  :1;
	volatile unsigned nRFBlnk_F       :1;
	volatile unsigned nRFPlusStrt_F   :1;
	volatile unsigned nRFPlusTmOt_F   :1;
//	volatile unsigned nRfOpn_F		  :1;
//	volatile unsigned nRFDlyTmOut_F   :1;
} __nRF24Flags;

typedef struct
{
	__nRFVars  nRFVars;
	__nRF24Flags nrFFlags;
} __nRF24Strk;

extern __nRF24Strk nRF24Strk;

/*----------------------------nrf24l01 Register address----------------------------*/

#define W_TX_PAYLOAD_NOACK ((uint8_t)0xB0)
#define R_RX_PAYLOAD       ((uint8_t)0x61)
#define WRT_REG_CMD        ((uint8_t)0x20)
#define READ_REG_CMD       ((uint8_t)0x00)
#define TX_CMD			   ((uint8_t)0xA0)

#define CONFIG_REG_ADDRS        ((uint8_t)0x00)
#define ENAA_REG_ADDRS          ((uint8_t)0x01)  // Auto-Acknowledgment
#define EN_RXADDR_ADDRS         ((uint8_t)0x02)  // Enabled RX Addresses
#define SETUP_AW_REG_ADDRS      ((uint8_t)0x03)  // Address Widths
#define SETUP_RETR_REG_ADDRS    ((uint8_t)0x04)  // Automatic Retransmission
#define RF_CH_REG_ADDRS         ((uint8_t)0x05)  // RF Channel
#define RF_SETUP_REG_ADDRS      ((uint8_t)0x06)  // RF Setup (Data rate, Power)
#define STATUS_REG_ADDRS        ((uint8_t)0x07)
#define RX_ADDR_P0_REG_ADDRS    ((uint8_t)0x0A)  // Receive Address Pipe 0
#define TX_ADDR_REG_ADDRS       ((uint8_t)0x10)  // Transmit Address
#define RX_PW_P0_REG_ADDRS      ((uint8_t)0x11)  // Payload Width Pipe 0
#define FEATURE_REG_ADDRS       ((uint8_t)0x1D)  // Feature Register
#define FLUSH_RX_FIFO			((uint8_t)0xE2)
#define FLUSH_TX_FIFO			((uint8_t)0xE1)
#define CLR_IRQ					((uint8_t)0x12)
#define START_LISTENING			((uint8_t)0x13)

/*-------------------- nRF receiver event ------------------*/
#define POLL_STATUS	 	((uint8_t)0x00)
#define CHECK_DATA   	((uint8_t)0x01)
#define READ_PAYLOAD 	((uint8_t)0x02)
#define PROCESS_PAYLOAD ((uint8_t)0x03)
#define CLR_RX_FLAG		((uint8_t)0x04)
#define DATETIME_SET    ((uint8_t)0x05)
/*-------------------- nRF receiver event end ----------------*/

/*-------------------- nRF transmitter event ------------------*/
#define NRF_TX_MODE		((uint8_t)0x00)
#define TRNSMT_DATA	 	((uint8_t)0x01)
#define PULSE_CE   	    ((uint8_t)0x02)
#define READ_STATUS 	((uint8_t)0x03)
#define CLR_STATUS      ((uint8_t)0x04)
#define FLSH_TXFIFO		((uint8_t)0x05)
#define NRF_RX_MODE		((uint8_t)0x06)

/*-------------------- nRF transmitter event end --------------*/

/*----------------------------nrf24l01 Register address end------------------------*/

#define CSN_LOW()   HAL_GPIO_WritePin(GPIOA, CSN_PA8_Pin, GPIO_PIN_RESET)
#define CSN_HIGH()  HAL_GPIO_WritePin(GPIOA, CSN_PA8_Pin, GPIO_PIN_SET)
#define CE_LOW()    HAL_GPIO_WritePin(GPIOB, CE_RXTX_PB12_Pin, GPIO_PIN_RESET)
#define CE_HIGH()   HAL_GPIO_WritePin(GPIOB, CE_RXTX_PB12_Pin, GPIO_PIN_SET)

void Init_nRF24      (void);
void nRF24_SetTxMode (void);
void nRF24_SetRxMode (void);
void nRFRx_Data      (void);
void nRFTx_Data		 (void);
void SetDly			 (uint16_t DlyCnt);
void nRF_SetCmd 	 (uint8_t NumofByt2Snd);
void nRF_Rx_Data	 (uint8_t NumOfByt2Rcv);

#endif /* INC_NRF_H_ */
