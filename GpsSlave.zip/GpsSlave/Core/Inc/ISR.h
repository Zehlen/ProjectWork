/*
 * ISR.h
 *
 *  Created on: 03-Sept-2026
 *      Author: Malcolm.X
 */

#ifndef INC_ISR_H_
#define INC_ISR_H_

#include "main.h"

#define SECDLY_CNT	    	((uint16_t)0x3E7)  // second delay count 999.
#define STTNGDLY_CNT    	((uint8_t)0x04)    // Clock setting delay count 4.
#define DSPLYDLY_CNT    	((uint8_t)0x01)    // Display delay count 1.
#define CLCKHRTDLY_CNT  	((uint16_t)0x1F3)  // Clock heart delay count 499.
#define CLCKDLY_CNT     	((uint8_t)0xC7)    // Clock delay count 199.
#define DBUNCDLY_CNT    	((uint8_t)0x13)    // key debounce delay count 19.
#define GPSDLY_CNT      	((uint8_t)0xC7)    // Modbus delay count 19.
#define GPSWRTDATETIME_CNT  ((uint8_t)0x000F)  // Write Delay count of DS3231.
#define GPSSGNLLED_CNT  	((uint8_t)0xFE)    // GPS signal led delay count.
#define DSPLYBLNK_CNT   	((uint16_t)0x18F)  // Display blink delay count 399.

#endif /* INC_ISR_H_ */
